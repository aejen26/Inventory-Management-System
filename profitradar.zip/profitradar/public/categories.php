<?php
// /public/categories.php — list & search categories
require_once __DIR__ . '/../includes/header.php';
require_login();
$pdo = getDB();

$q = trim($_GET['q'] ?? '');
$sql = "SELECT id, name, description, created_at FROM categories WHERE 1";
$params = [];
if ($q !== '') { $sql .= " AND (name LIKE ? OR description LIKE ?)"; $params=['%'.$q.'%','%'.$q.'%']; }
$sql .= " ORDER BY name ASC LIMIT 200";
$st = $pdo->prepare($sql); $st->execute($params);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Categories</h4>
  <?php if (has_role(['admin','staff'])): ?>
    <a class="btn btn-primary" href="/profitradar/public/category_edit.php">Add Category</a>
  <?php endif; ?>
</div>

<form class="row g-2 mb-3">
  <div class="col-md-6">
    <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Search name or description">
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-secondary w-100">Search</button>
  </div>
</form>

<table class="table table-striped table-sm align-middle">
  <thead><tr><th>Name</th><th>Description</th><th>Created</th><?php if (has_role(['admin','staff'])): ?><th class="text-end"></th><?php endif; ?></tr></thead>
  <tbody>
    <?php foreach ($st as $c): ?>
      <tr>
        <td><?= h($c['name']) ?></td>
        <td><?= h($c['description']) ?></td>
        <td><?= h($c['created_at']) ?></td>
        <?php if (has_role(['admin','staff'])): ?>
        <td class="text-end">
          <a class="btn btn-sm btn-outline-secondary" href="/profitradar/public/category_edit.php?id=<?= (int)$c['id'] ?>">Edit</a>
          <?php if (has_role('admin')): ?>
            <a class="btn btn-sm btn-outline-danger" href="/profitradar/public/category_delete.php?id=<?= (int)$c['id'] ?>"
               onclick="return confirm('Delete this category? Products will keep the link but the name will vanish.');">Delete</a>
          <?php endif; ?>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if ($st->rowCount() === 0): ?>
      <tr><td colspan="4" class="text-muted">No categories yet.</td></tr>
    <?php endif; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
