<?php
// /public/settings.php — Global Settings (Low Stock Threshold)
require_once __DIR__ . '/../includes/header.php';
require_role(['admin']);  // only admins can change global settings
$pdo = getDB();

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  check_csrf();
  $val = trim($_POST['low_stock_default'] ?? '');
  if ($val === '' || !ctype_digit($val) || (int)$val < 0) {
      $err = 'Please enter a non-negative whole number.';
  } else {
      try {
          set_setting($pdo, 'low_stock_default', (string)(int)$val);
          $msg = '✅ Global low stock threshold updated.';
      } catch (Throwable $e) {
          $err = 'Save failed: ' . h($e->getMessage());
      }
  }
}

// read current value (default to 5 if none)
$current = (int)get_setting($pdo, 'low_stock_default', 5);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Settings</h4>
</div>

<?php if ($msg): ?>
  <div class="alert alert-success"><?= $msg ?></div>
<?php endif; ?>
<?php if ($err): ?>
  <div class="alert alert-danger"><?= $err ?></div>
<?php endif; ?>

<form method="post" class="row g-3" style="max-width: 520px;">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <div class="col-12">
    <label class="form-label">Global Low Stock Threshold</label>
    <input class="form-control" type="number" min="0" step="1"
           name="low_stock_default" value="<?= h($current) ?>">
    <div class="form-text">
      Products with <code>stock_qty</code> below this number will trigger a low-stock alert,
      unless a per-product threshold is set.
    </div>
  </div>
  <div class="col-12 text-end">
    <a class="btn btn-outline-secondary" href="/profitradar/public/dashboard.php">Cancel</a>
    <button class="btn btn-primary">Save</button>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
