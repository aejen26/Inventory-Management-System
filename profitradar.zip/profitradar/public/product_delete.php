<?php
ob_start();
require_once __DIR__.'/../includes/header.php';
require_role(['admin']);
$pdo=getDB();
$id=(int)($_GET['id']??0);
if($id){
  $pdo->prepare('UPDATE products SET is_active=0, updated_at=NOW() WHERE id=?')->execute([$id]);
  log_action($pdo,current_user()['id'],'archive','products',$id,'Product archived',null,null);
}
header('Location: /profitradar/public/products.php');