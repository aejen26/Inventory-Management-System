<?php
// public/stock_adjust.php — Final version (no notes, auto AJAX detection, fixed round() issue)
declare(strict_types=1);

// detect AJAX
$headers = function_exists('getallheaders') ? getallheaders() : [];
$isAjax = (
  (isset($headers['X-Requested-With']) && strtolower($headers['X-Requested-With']) === 'xmlhttprequest')
  || (isset($headers['Accept']) && strpos($headers['Accept'], 'application/json') !== false)
  || (isset($_REQUEST['ajax']) && $_REQUEST['ajax'] === '1')
);

if (!$isAjax) {
  require_once __DIR__ . '/../includes/header.php';
}

require_once __DIR__ . '/../includes/db.php';
if (function_exists('check_csrf')) check_csrf();

// ----------------- Ensure $pdo is available -----------------
// Some projects export $pdo directly from includes/db.php, others provide getDB().
// Handle both: prefer existing $pdo, otherwise call getDB() if present.
// If neither exists, throw a clear exception (will be logged by our AJAX handler).
if (!isset($pdo) || !($pdo instanceof PDO)) {
    if (function_exists('getDB')) {
        $pdo = getDB();
    } elseif (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
        $pdo = $GLOBALS['pdo'];
    } else {
        // If AJAX request, respond with JSON error; otherwise throw so dev can see it.
        $msg = 'Database connection not found: $pdo not set and getDB() missing.';
        // Log and then either return JSON (for AJAX) or throw exception.
        @file_put_contents(__DIR__ . '/../logs/stock_adjust.log', date('c') . " ERROR: $msg" . PHP_EOL, FILE_APPEND);
        if ((isset($isAjax) && $isAjax) || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')) {
            header_remove();
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>false, 'msg' => $msg, 'applied' => [], 'stocks' => []]);
            exit;
        }
        throw new RuntimeException($msg);
    }
}

$LOG = __DIR__ . '/../logs/stock_adjust.log';
@mkdir(dirname($LOG), 0777, true);
function logit($m){ global $LOG; file_put_contents($LOG, date('c').' '.$m.PHP_EOL, FILE_APPEND); }

// Load data
$categories = $pdo->query("SELECT id,name FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$products = $pdo->query("
  SELECT id, code, name, category_id, unit, sold_by,
         COALESCE(stock_qty,0) AS stock_qty,
         COALESCE(retail_stock,COALESCE(stock_qty,0)) AS retail_stock,
         COALESCE(wholesale_stock,COALESCE(stock_qty,0)) AS wholesale_stock
  FROM products
  WHERE is_active=1
  ORDER BY name
")->fetchAll(PDO::FETCH_ASSOC);

/* ---------------------- AJAX REQUEST HANDLER ---------------------- */
/* ---------------------- AJAX REQUEST HANDLER (buffered, safe JSON) ---------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAjax) {
  // start buffering everything so accidental echoes / warnings don't corrupt JSON
  ob_start();

  // remove any default headers and force JSON header later
  header_remove();
  header('Content-Type: application/json; charset=utf-8');

  $resp = ['ok' => false, 'msg' => '', 'applied' => [], 'stocks' => []];

  try {
    $items = $_POST['items'] ?? [];
    if (!$items || !is_array($items)) throw new Exception('No adjustments submitted.');

    $pdo->beginTransaction();
    $sel = $pdo->prepare("SELECT COALESCE(stock_qty,0) AS stock_qty FROM products WHERE id=:id FOR UPDATE");
    $upd = $pdo->prepare("
      UPDATE products 
      SET stock_qty=:stock_qty, retail_stock=:r, wholesale_stock=:w, updated_at = CURRENT_TIMESTAMP
      WHERE id=:id
    ");

    $applied = [];
    foreach ($items as $it) {
      $pid = (int)($it['product_id'] ?? 0);
      $delta_raw = $it['delta'] ?? '';
      if ($pid <= 0 || $delta_raw === '' || !is_numeric($delta_raw)) continue;

      $delta = (float)$delta_raw;
      $sel->execute([':id' => $pid]);
      $row = $sel->fetch(PDO::FETCH_ASSOC);
      if (!$row) throw new Exception("Product id {$pid} not found.");

      $before = (float)$row['stock_qty'];
      $after = (float)round($before + $delta, 3);
      if ($after < 0) $after = 0.0;

      $upd->execute([
        ':stock_qty' => $after,
        ':r' => $after,
        ':w' => $after,
        ':id' => $pid
      ]);

      $applied[] = [
        'product_id' => $pid,
        'before' => $before,
        'after' => $after,
        'delta' => $delta
      ];

      logit("Adjusted PID {$pid}: before={$before}, delta={$delta}, after={$after}");
    }

    $pdo->commit();

    // ✅ Log this adjustment into audit_log for tracking in All Movements
try {
    $logStmt = $pdo->prepare("
        INSERT INTO audit_log (user_id, description, new_data, created_at)
        VALUES (:user_id, :desc, :data, NOW())
    ");
    $desc = 'Stock adjusted (' . count($applied) . ' items)';
    $newData = json_encode(['meta' => ['type' => 'stock_adjust'], 'items' => $applied], JSON_UNESCAPED_UNICODE);
    $logStmt->execute([
        ':user_id' => $_SESSION['user']['id'] ?? null,
        ':desc' => $desc,
        ':data' => $newData
    ]);
} catch (Throwable $logErr) {
    // optional: silently log to file if audit insert fails
    @file_put_contents(__DIR__.'/../logs/stock_adjust.log',
        date('c') . ' AUDIT_LOG_INSERT_FAIL: ' . $logErr->getMessage() . PHP_EOL,
        FILE_APPEND
    );
}

    // fetch latest stock
    $ids = array_column($applied,'product_id');
    if ($ids) {
      $in = implode(',', array_map('intval',$ids));
      $q = $pdo->query("SELECT id, COALESCE(stock_qty,0) AS stock_qty FROM products WHERE id IN ($in)");
      foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $resp['stocks'][(int)$r['id']] = (float)$r['stock_qty'];
      }
    }

    $resp['ok'] = true;
    $resp['msg'] = 'Adjustments applied successfully.';
    $resp['applied'] = $applied;

    // capture and log any accidental output, but do NOT send it to client
    $extra = ob_get_clean();
    if ($extra !== '') {
      // shrink whitespace for log readability
      $short = preg_replace('/\s+/', ' ', trim($extra));
      logit("EXTRA_OUTPUT (cleared): " . $short);
    }

    echo json_encode($resp);
    exit;
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // grab any buffered output for debugging
    $extra = ob_get_clean();
    if ($extra !== '') {
      $short = preg_replace('/\s+/', ' ', trim($extra));
      logit("EXTRA_OUTPUT_ON_ERROR: " . $short);
    }
    $errMsg = $e->getMessage();
    logit('ERROR: ' . $errMsg);
    http_response_code(400);
    $resp['msg'] = 'Server error: ' . $errMsg;
    echo json_encode($resp);
    exit;
  }
}

/* ---------------------- HTML RENDER ---------------------- */
?>
<style>
.container-wide { max-width:1100px; margin:18px auto; }
.adj-row { display:flex; gap:12px; align-items:center; padding:10px; border:1px solid #eef2f5; border-radius:8px; background:#fff; margin-bottom:8px; }
/* --- Fix: Keep navbar clickable even after adjustments --- */
header, .navbar, nav.navbar, .navbar-default, .navbar-inverse {
  position: relative !important;
  z-index: 9999 !important;
  pointer-events: auto !important;
}

/* Ensure main page elements stay below the header */
body, .container, .container-wide, #productList, .adj-row {
  position: relative;
  z-index: 1;
}

/* Optional: remove invisible overlays if any were left behind */
.modal-backdrop, .overlay, .site-overlay, #overlay, .backdrop {
  pointer-events: none !important;
  opacity: 0 !important;
  visibility: hidden !important;
}
.meta { flex:1; }
.unit-badge { padding:4px 8px; border-radius:999px; background:#f1f3f5; font-weight:700; font-size:0.85rem; color:#212529; margin-left:6px; }
.stock-val { font-weight:700; min-width:80px; text-align:right; }
.adjust-input { width:150px; }
.queued-list { margin-top:10px; }
</style>

<div class="container container-wide">
  <h4>Stock Transfer </h4>

  <div class="row mb-3">
    <div class="col-md-4">
      <label class="form-label">Category</label>
      <select id="categorySelect" class="form-select form-select-sm">
        <option value="">All Categories</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-8">
      <label class="form-label">Search</label>
      <input id="search" class="form-control form-control-sm" placeholder="Search code or name...">
    </div>
  </div>

  <form id="adjustForm" method="post">
    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
    <!--<div id="hiddenItems"></div>-->

    <div id="productList">
      <?php foreach ($products as $p):
        $unit = $p['unit'] ?: ($p['sold_by']==='weight' ? 'kg' : 'pc');
        $stock = $p['stock_qty'];
        if ($p['sold_by'] === 'weight') $stock = rtrim(rtrim(number_format((float)$stock,3,'.',''),'0'),'.');
        else $stock = (int)round((float)$stock);
      ?>
        <div class="adj-row" data-cat="<?= (int)$p['category_id'] ?>">
          <div class="meta">
            <div style="font-weight:700"><?= h($p['code']) ?> — <?= h($p['name']) ?> <span class="unit-badge"><?= h($unit) ?></span></div>
            <div class="small text-muted">sold_by: <?= h($p['sold_by'] ?: 'each') ?></div>
          </div>
          <div class="stock-val" data-pid="<?= (int)$p['id'] ?>"><?= h($stock) ?></div>
          <div>
            <input class="form-control form-control-sm adjust-input" 
                   type="number" 
                   step="<?= ($p['sold_by']==='weight' ? '0.001' : '1') ?>" 
                   placeholder="<?= ($p['sold_by']==='weight' ? 'decimals allowed' : 'integer') ?>" 
                   data-pid="<?= (int)$p['id'] ?>">
            <div class="small text-muted">+ or - (e.g. +2 or -1)</div>
          </div>
          <div><button type="button" class="btn btn-sm btn-primary btn-queue" data-pid="<?= (int)$p['id'] ?>">Add</button></div>
        </div>
      <?php endforeach; ?>
    </div>

    

        <div class="mt-2">
      <div id="statusBox" class="small text-muted">Adjustments will be applied immediately when you press <strong>Add</strong>.</div>
    </div>
  </form>

  <div id="alertBox" style="display:none; margin-top:12px;"></div>
</div>

<script>
const PRODUCTS = <?= json_encode($products, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
const alertBox = document.getElementById('alertBox');
const categorySelect = document.getElementById('categorySelect');
const searchInput = document.getElementById('search');
const statusBox = document.getElementById('statusBox');

function showAlert(msg, type='success'){ 
  alertBox.style.display='block'; 
  alertBox.className = 'alert alert-' + (type==='success' ? 'success' : 'danger'); 
  alertBox.textContent = msg; 
  setTimeout(()=>{ alertBox.style.display='none'; }, 3000); 
}

function fmtStock(val, sold_by){
  if (sold_by === 'weight') {
    return parseFloat(val).toFixed(3).replace(/\.?0+$/,'');
  }
  return parseInt(Math.round(val));
}

/* helper: send adjustments to server (items array), returns parsed JSON or throws */
async function sendAdjustments(items){
  if (!items || !items.length) throw new Error('No items to send');

  const fd = new FormData();
  fd.append('ajax', '1');
  fd.append('csrf', document.querySelector('input[name="csrf"]').value);
  items.forEach((q, i) => {
    fd.append(`items[${i}][product_id]`, q.product_id);
    fd.append(`items[${i}][delta]`, q.delta);
  });

  const res = await fetch(window.location.href, { 
    method: 'POST', 
    body: fd, 
    credentials: 'same-origin' 
  });

  const text = await res.text();

  // Log raw server response for debugging
  if (typeof console !== 'undefined') {
    console.log('RAW SERVER RESPONSE:', text);
  }

  let j;
  try {
    j = JSON.parse(text);
  } catch (e) {
    const preview = text.length > 1000 
      ? text.slice(0, 1000) + '...[truncated]' 
      : text;
    throw new Error('Server returned invalid JSON. Server output preview: ' + preview);
  }

  if (!res.ok) {
    throw new Error(j.msg || ('HTTP ' + res.status));
  }

  return j;
}


/* Add button behaviour: always send single-item request immediately */
document.addEventListener('DOMContentLoaded', function() {
  /* Add button behaviour: always send single-item request immediately */
  document.querySelectorAll('.btn-queue').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const pid = btn.dataset.pid;
      const inp = document.querySelector('.adjust-input[data-pid="'+pid+'"]');
      const val = inp ? inp.value : '';
      if (val === '' || isNaN(val) || Number(val) === 0) { alert('Enter a non-zero number'); return; }
      const delta = Number(val);

      btn.disabled = true;
      if (inp) inp.disabled = true;
      statusBox.textContent = 'Applying adjustment...';

      try {
        const j = await sendAdjustments([{ product_id: parseInt(pid), delta: delta }]);
        // update displayed stock for affected items
        if (j.stocks){
          for (const [id, s] of Object.entries(j.stocks)){
            const el = document.querySelector('.stock-val[data-pid="'+id+'"]');
            if (el){
              const prod = PRODUCTS.find(p=>String(p.id)===String(id));
              el.textContent = fmtStock(s, prod ? prod.sold_by : null);
              // update PRODUCTS array for later adjustments
              if (prod) prod.stock_qty = s;
            }
          }
        }
        showAlert(j.msg || 'Adjustment applied');
        statusBox.textContent = 'Adjustment applied.';
      } catch (err) {
        showAlert('Error: '+err.message, 'error');
        console.error(err);
        statusBox.textContent = 'Error applying adjustment.';
      } finally {
        btn.disabled = false;
        if (inp) inp.disabled = false;
        if (inp) inp.value = '';
        // reset status after a short while
        setTimeout(()=>{ statusBox.textContent = 'Adjustments will be applied immediately when you press Add.'; }, 2000);
      }
    });
  });

  /* filter list */
  function filterList(){
    const cat = categorySelect.value;
    const q = (searchInput.value||'').trim().toLowerCase();
    document.querySelectorAll('#productList .adj-row').forEach(row=>{
      const rowCat = row.dataset.cat;
      const text = row.textContent.toLowerCase();
      if (cat && String(rowCat)!==String(cat)) { row.style.display='none'; return; }
      if (q && !text.includes(q)) { row.style.display='none'; return; }
      row.style.display='';
    });
  }
  categorySelect.addEventListener('change', filterList);
  searchInput.addEventListener('input', filterList);

  filterList();
});
</script>
<?php if (!$isAjax) require_once __DIR__ . '/../includes/footer.php'; ?>

