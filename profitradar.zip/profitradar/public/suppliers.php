<?php
// /public/suppliers.php — list & search suppliers
require_once __DIR__ . '/../includes/header.php';
require_login();
$pdo = getDB();

$q = trim($_GET['q'] ?? '');
$sql = "SELECT id, name, contact, phone, email FROM suppliers WHERE 1";
$params = [];
if ($q !== '') {
  $sql .= " AND (name LIKE ? OR contact LIKE ? OR phone LIKE ? OR email LIKE ?)";
  $params = array_fill(0, 4, '%'.$q.'%');
}
$sql .= " ORDER BY name ASC LIMIT 200";
$st = $pdo->prepare($sql); $st->execute($params);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Suppliers</h4>
  <?php if (has_role(['admin','staff'])): ?>
    <a class="btn btn-primary" href="/profitradar/public/supplier_edit.php">Add Supplier</a>
  <?php endif; ?>
</div>

<form class="row g-2 mb-3">
  <div class="col-md-6">
    <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Search by name, contact, phone, or email">
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-secondary w-100">Search</button>
  </div>
</form>

<table class="table table-striped table-sm align-middle">
  <thead>
    <tr>
      <th>Name</th>
      <th>Contact</th>
      <th>Phone</th>
      <th>Email</th>
      <?php if (has_role(['admin','staff'])): ?><th class="text-end"></th><?php endif; ?>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($st as $r): ?>
      <tr>
        <td><?= h($r['name']) ?></td>
        <td><?= h($r['contact']) ?></td>
        <td><?= h($r['phone']) ?></td>
        <td><?= h($r['email']) ?></td>
        <?php if (has_role(['admin','staff'])): ?>
        <td class="text-end">
          <a class="btn btn-sm btn-outline-secondary" href="/profitradar/public/supplier_edit.php?id=<?= (int)$r['id'] ?>">Edit</a>
          <?php if (has_role('admin')): ?>
          <a class="btn btn-sm btn-outline-danger" href="/profitradar/public/supplier_delete.php?id=<?= (int)$r['id'] ?>"
             onclick="return confirm('Delete this supplier? This will set supplier_id to NULL on products/transactions.');">Delete</a>
          <?php endif; ?>
        </td>
        <?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if ($st->rowCount() === 0): ?>
      <tr><td colspan="5" class="text-muted">No suppliers yet.</td></tr>
    <?php endif; ?>
  </tbody>
</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
