<?php
ob_start();
// public/sale_add.php — Loyverse-style POS with per-item + invoice discounts
require_once __DIR__.'/../includes/header.php';
require_role(['admin','staff']);

$pdo = getDB();
check_csrf(); // will only validate POSTs

$msg = '';

// Load products + categories + customers
$products = $pdo->query("
  SELECT id, code, name, stock_qty, unit, sold_by,
         sell_price, wholesale_price,
         promo_discount_type, promo_discount_value,
         category_id
  FROM products
  WHERE is_active=1
  ORDER BY name
")->fetchAll(PDO::FETCH_ASSOC);

$categories = $pdo->query("SELECT id,name FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$customers  = $pdo->query("SELECT id,name FROM customers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// index products for server-side lookups
$pindex = [];
foreach ($products as $p) $pindex[(int)$p['id']] = $p;

/* ---------------- Tickets (session) ---------------- */
if (!isset($_SESSION['tickets'])) $_SESSION['tickets'] = [];

/* Delete ticket */
if (isset($_GET['delete_ticket'])) {
  $del = (string)($_GET['delete_ticket'] ?? '');
  if ($del !== '') {
    foreach ($_SESSION['tickets'] as $k=>$t) {
      if ($t['id'] === $del) { unset($_SESSION['tickets'][$k]); $_SESSION['tickets'] = array_values($_SESSION['tickets']); break; }
    }
  }
  header('Location: sale_add.php'); exit;
}

/* Load ticket */
$initialTicket = null;
if (isset($_GET['load_ticket'])) {
  $load = (string)($_GET['load_ticket'] ?? '');
  foreach ($_SESSION['tickets'] as $t) {
    if ($t['id'] === $load) { $initialTicket = $t; break; }
  }
}

/* ---------------- POST handling ----------------
   Supports two actions:
    - save_ticket  (park ticket into session)
    - save_sale    (create transaction using create_transaction())
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? 'save_sale';

  try {
    // normalized common inputs (avoid notices)
    $customer_id_raw = $_POST['customer_id'] ?? '';
    $customer_id = ($customer_id_raw !== '') ? (int)$customer_id_raw : null;
    $date  = $_POST['date'] ?? date('Y-m-d');
    $notes = trim($_POST['notes'] ?? '');
    $sale_mode = ($_POST['sale_mode'] ?? 'retail') === 'wholesale' ? 'wholesale' : 'retail';

    // invoice-level discount (posted from hidden form)
    $inv_disc_type  = $_POST['inv_discount_type'] ?? null;
    $inv_disc_value = (isset($_POST['inv_discount_value']) && $_POST['inv_discount_value'] !== '') ? (float)$_POST['inv_discount_value'] : null;
    if (!in_array($inv_disc_type, ['percent','amount',null], true)) { $inv_disc_type = null; $inv_disc_value = null; }
    if ($inv_disc_value !== null && $inv_disc_value < 0) $inv_disc_value = null;

    // collect posted items raw (including discount fields)
    $rawItems = [];
    foreach ($_POST['items'] ?? [] as $it) {
      $rawItems[] = [
        'product_id' => (int)($it['product_id'] ?? 0),
        'qty' => ($it['qty'] ?? ''), // keep as string for ticket save
        'unit_price' => ($it['unit_price'] ?? ''),
        'price_tier' => ($it['price_tier'] ?? $sale_mode),
        'discount_type' => ($it['discount_type'] ?? null),       // 'percent'|'amount'|null
        'discount_value' => ($it['discount_value'] ?? ''),      // may be ''
      ];
    }

    if ($action === 'save_ticket') {
      // minimal validation
      $has = false;
      foreach ($rawItems as $r) { if ($r['product_id'] > 0) { $has = true; break; } }
      if (!$has) {
        $msg = 'Please add at least one item to save ticket.';
      } else {
        // --- ENRICH items with code & name so ticket preview shows correctly ---
        $ticketItems = [];
        foreach ($rawItems as $r) {
          $pid = (int)$r['product_id'];
          if ($pid <= 0) continue;
          $prod = $pindex[$pid] ?? null;
          // keep posted qty/unit_price/discount but also include code/name for preview
          $ticketItems[] = [
            'product_id' => $pid,
            'code' => $prod ? ($prod['code'] ?? '') : '',
            'name' => $prod ? ($prod['name'] ?? '') : '',
            'qty' => $r['qty'],
            'unit_price' => $r['unit_price'],
            'price_tier' => $r['price_tier'],
            'discount_type' => $r['discount_type'] ?? null,
            'discount_value' => ($r['discount_value'] !== '') ? (float)$r['discount_value'] : null
          ];
        }

        $ticket = [
          'id' => bin2hex(random_bytes(8)),
          'created_at' => date('c'),
          'date' => $date,
          'customer_id' => $customer_id,
          'sale_mode' => $sale_mode,
          'notes' => $notes,
          'inv_discount_type' => $inv_disc_type,
          'inv_discount_value' => $inv_disc_value,
          'items' => $ticketItems
        ];
        $_SESSION['tickets'][] = $ticket;
        $msg = '✅ Ticket saved.';
        header('Location: sale_add.php'); exit;
      }
    }

    if ($action === 'save_sale') {
      // Build canonical $clean items for create_transaction
      $clean = [];
      foreach ($rawItems as $r) {
        $pid = (int)$r['product_id'];
        if ($pid <= 0 || !isset($pindex[$pid])) continue;
        $prod = $pindex[$pid];

        // qty normalization:
        $qtyIn = (float)($r['qty'] === '' ? 0 : $r['qty']);
        if ($prod['sold_by'] === 'weight') {
          // allow decimals — nearest 0.25 (quarter kilo) by default
          $qty = max(0.25, round($qtyIn * 4) / 4);
        } else {
          $qty = (int)round($qtyIn);
        }
        if ($qty <= 0) continue;

        // server-side unit price (trust DB)
        if ($sale_mode === 'wholesale') {
          $unit = (float)$prod['wholesale_price']; if ($unit <= 0) $unit = (float)$prod['sell_price'];
        } else {
          $unit = (float)$prod['sell_price'];
        }
        $unit = round($unit, 2);

        // sanitize posted per-line discount (take posted values if present)
        $dt = $r['discount_type'] ?? null;
        $dv = ($r['discount_value'] !== '') ? (float)$r['discount_value'] : null;
        if (!in_array($dt, ['percent','amount',null], true)) { $dt = null; $dv = null; }
        if ($dv !== null && $dv < 0) { $dt = null; $dv = null; }
        if ($dt === 'percent' && $dv !== null) { $dv = max(0, min(100, $dv)); }

        // apply promo discount from product if present and no explicit line discount
        if ($dt === null && !empty($prod['promo_discount_type']) && $prod['promo_discount_value'] !== null) {
          $dt = $prod['promo_discount_type'];
          $dv = (float)$prod['promo_discount_value'];
        }

        $clean[] = [
          'product_id' => $pid,
          'qty' => $qty,
          'unit_price' => $unit,
          'discount_type' => $dt,
          'discount_value' => $dv,
          'price_tier' => $sale_mode
        ];
      }

      if (!$clean) {
        $msg = 'Please add at least one valid item.';
      } else {
        // create sale transaction with invoice discount passed through
        create_transaction(
          $pdo, 'sale', current_user()['id'], $date, $notes,
          null, $customer_id, $clean,
          $inv_disc_type, $inv_disc_value,
          $sale_mode
        );
        $msg = '✅ Sale recorded.';
        header('Location: sale_add.php'); exit;
      }
    }

  } catch (Throwable $e) {
    $msg = 'Error: '.h($e->getMessage());
  }
}

/* ---------------- Initial items for JS if ticket loaded -------------- */
$initialItems = [];
if ($initialTicket) {
  foreach ($initialTicket['items'] as $it) {
    $pid = (int)($it['product_id'] ?? 0);
    if ($pid <= 0 || !isset($pindex[$pid])) continue;
    $prod = $pindex[$pid];
    // unit price from DB (display only) — prefer posted unit_price in ticket if present
    $unit = ($initialTicket['sale_mode'] ?? 'retail') === 'wholesale' ? (float)$prod['wholesale_price'] : (float)$prod['sell_price'];
    $initialItems[] = [
      'product_id' => $pid,
      'qty' => (string)($it['qty'] ?? '1'),
      'unit_price' => number_format($unit,2,'.',''),
      'price_tier' => $initialTicket['sale_mode'] ?? 'retail',
      'discount_type' => $it['discount_type'] ?? null,
      'discount_value' => isset($it['discount_value']) ? $it['discount_value'] : null
    ];
  }
}

/* ---------------- Render UI ---------------- */
?>
<style>
/* Modernized Loyverse-like theme adjustments */
:root {
  --card-bg: #ffffff;
  --muted: #6c757d;
  --accent: #0d6efd;
  --surface: #fafbfc;
}

/* layout */
.lr-top { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:12px; }
.lr-left { width:68%; }
.lr-right { width:32%; }

/* Top card wrapper */
.pos-top-card {
  background: var(--card-bg);
  border-radius: 10px;
  padding: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  margin-bottom: 12px;
}

/* category + controls */
.lr-cats { display:flex; gap:10px; align-items:center; margin-bottom:10px; flex-wrap:wrap; }
#categoriesBar label { margin-right:6px; color:var(--muted); font-weight:600; }
#categoriesBar select { max-width:320px; border-radius:10px; padding:6px 10px; border-color:#dfe4e8; transition: box-shadow .15s, border-color .15s; }

/* focus state */
#categoriesBar select:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 0 4px rgba(13,110,253,0.08);
}

/* Product grid tweaks */
.product-grid {
  display:grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 14px;
}
.product-card {
  height: 120px;
  border: 1px solid #e8edf1;
  border-radius: 10px;
  padding: 12px;
  background: var(--surface);
  transition: transform .15s ease, box-shadow .15s ease, background .15s ease;
  cursor: pointer;
  display:flex;
  justify-content:space-between;
  flex-direction:column;
}
.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 18px rgba(20,30,50,0.06);
  background: #fff;
}
.product-title { font-weight:600; font-size:14px; color:#222; }
.product-meta { font-size:12px; color:#6c757d; }

/* Right panel improvements */
.lr-right .ticket {
  border-radius: 12px;
  padding: 14px;
  box-shadow: 0 6px 18px rgba(20,30,50,0.04);
  background: #fff;
}
.ticket .small-muted { font-size:12px; color:var(--muted); }

/* Buttons */
.btn-loy {
  border-radius: 8px;
  font-weight: 600;
  background: var(--accent);
  color: #fff;
  border: 0;
}
.btn-loy:active, .btn-loy:focus { box-shadow: 0 2px 8px rgba(13,110,253,0.18); }

/* Inputs */
.qty-input { width:90px; margin-left:auto; }
.disc-select { width:90px; display:inline-block; margin-right:6px; }
.disc-input  { width:80px; display:inline-block; }
.line-disc   { font-size:12px; color:#666; }

/* Saved tickets area */
.list-group-item { border-radius:8px; margin-bottom:6px; }

/* responsive tweak: stack right panel under left on small screens */
@media (max-width: 991px) {
  .lr-left, .lr-right { width:100%; }
  .product-grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }
}
/* ===== FORCE layout override - paste at end of existing <style> block ===== */

/* Make the left / right columns a fixed flex split so it always shows bigger right panel */
.row.g-3 { display: flex !important; gap: 1rem !important; align-items: flex-start; }

/* Left column (product area) - reduce width */
.lr-left {
  flex: 0 0 58% !important;
  max-width: 58% !important;
}

/* Right column (ticket) - increase width */
.lr-right {
  flex: 0 0 42% !important;
  max-width: 42% !important;
}

/* Ensure product grid doesn't overflow and uses smaller columns */
.product-grid {
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)) !important;
  gap: 14px !important;
}

/* Make ticket more compact but visually prominent */
.lr-right .ticket {
  padding: 18px !important;
  box-shadow: 0 10px 30px rgba(20,30,50,0.08) !important;
  border-radius: 12px !important;
}

/* Make controls and dropdown clearer */
#categoriesBar select { border-radius: 10px !important; padding: 6px 10px !important; }

/* Slightly increase action button prominence */
.btn-loy { padding: 10px 12px !important; border-radius: 8px !important; }

/* Mobile fallback: stack columns */
@media (max-width: 991px) {
  .row.g-3 { flex-direction: column !important; }
  .lr-left, .lr-right { max-width: 100% !important; flex: 0 0 100% !important; }
}
.lr-right .ticket {
  transform: scale(1.0);
  transform-origin: top right;
}
/* Compact product grid for smaller left side */
.product-grid {
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)) !important;
  gap: 10px !important;
}

.product-card {
  height: 100px !important;
  padding: 8px !important;
  border-radius: 8px !important;
  font-size: 0.9rem !important;
}

.product-title { font-size: 13px !important; }
.product-meta  { font-size: 11px !important; color: #6c757d; }
/* --- Enhanced Ticket Panel --- */
.lr-right .ticket {
  padding: 24px !important;            /* more breathing space */
  border-radius: 14px !important;
  box-shadow: 0 12px 30px rgba(0,0,0,0.08) !important;
  background: #fff;
  font-size: 1.02rem;
  transition: transform 0.2s ease;
}

.lr-right .ticket:hover {
  transform: scale(1.01);
}

/* bigger total + better spacing */
#ticketGrandTotal {
  font-size: 2rem !important;
  font-weight: 700 !important;
  color: #0d6efd !important;
}

#ticketSubtotal,
#ticketDiscountTotal {
  font-size: 1rem !important;
  font-weight: 500;
  color: #444;
}

/* enlarge buttons */
.btn-loy {
  padding: 12px 0 !important;
  font-size: 1.05rem !important;
  border-radius: 10px !important;
}

.btn-outline-secondary,
.btn-primary {
  font-size: 1rem !important;
  border-radius: 10px !important;
}

/* make invoice discount and totals more readable */
.ticket select,
.ticket input[type="number"] {
  font-size: 0.95rem !important;
  height: 32px;
}

.ticket table th,
.ticket table td {
  font-size: 0.95rem;
  vertical-align: middle;
}

/* smoother ticket shadow on dark navbar background */
body {
  background-color: #f8f9fa;
}
/* --- Border Enhancement Styles --- */

/* Outer layout separation (left & right areas) */
.lr-left {
  border: 5px solid #dee2e6 !important;
  border-radius: 10px;
  padding: 12px;
  background-color: #fff;
  box-shadow: 0 2px 6px rgba(0,0,0,0.03);
}

.lr-right {
  border: 5px solid #dee2e6 !important;
  border-radius: 10px;
  padding: 10px;
  background-color: #fff;
  box-shadow: 0 3px 10px rgba(0,0,0,0.05);
}

/* Ticket panel */
.lr-right .ticket {
  border: 5px solid #ced4da !important;
  border-radius: 14px !important;
  padding: 24px !important;
  background: #fff;
  box-shadow: 0 4px 12px rgba(0,0,0,0.06);
  transition: all 0.2s ease;
}

.lr-right .ticket:hover {
  box-shadow: 0 6px 18px rgba(0,0,0,0.08);
  border-color: #adb5bd !important;
}

/* Each row in the ticket table */
.ticket table th,
.ticket table td {
  border-bottom: 1px solid #e9ecef !important;
  vertical-align: middle;
}

/* Invoice discount area border top */
.ticket .d-flex.gap-2.align-items-center.mb-2 {
  border-top: 5px solid #dee2e6;
  padding-top: 8px;
  margin-top: 10px;
}

/* Total and grand total sections */
#ticketGrandTotal {
  border-top: 5px solid #dee2e6;
  padding-top: 10px;
  margin-top: 6px;
  font-size: 2rem !important;
  font-weight: 700;
  color: #0d6efd;
}

#ticketSubtotal,
#ticketDiscountTotal {
  border-bottom: px solid #f1f3f5;
  padding-bottom: 4px;
  font-size: 1rem;
  color: #333;
}

/* Product cards */
.product-card {
  border: 5px solid #dee2e6 !important;
  background-color: #fff;
  border-radius: 10px;
  padding: 10px;
  height: 110px;
  transition: all 0.2s ease-in-out;
}
.product-card:hover {
  border-color: #0d6efd !important;
  box-shadow: 0 4px 12px rgba(13,110,253,0.15);
}

/* Category dropdown and search border alignment */
.pos-top-card {
  border: 5px solid #dee2e6;
  border-radius: 10px;
  background: #fff;
  padding: 12px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.03);
}
#categoriesBar select {
  border: 1px solid #ced4da;
  border-radius: 8px;
}

/* Buttons with slight outline when hovered */
.btn-loy {
  border: 5px solid #0b5ed7 !important;
}
.btn-outline-secondary:hover {
  border-color: #6c757d !important;
}

/* Optional subtle border between sections */
body {
  background-color: #f8f9fa;
}
/* category icon inside product card */
.product-card { position: relative; overflow: visible; }
.cat-icon {
  position: absolute;
  top: 10px;
  left: 10px;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 700;
  font-size: 13px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.12);
  border: 2px solid rgba(255,255,255,0.6);
  text-transform: uppercase;
  line-height: 1;
}
/* Don’t let ticket cells wrap to a new line */
  #ticketTable th,
  #ticketTable td {
    white-space: nowrap;
  }

  /* Item column: allow long names but keep row single-line with ellipsis */
  #ticketTable td:first-child {
    max-width: 260px;          /* adjust if you want more/less */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Make Qty and Discount columns narrower so Total has space */
  #ticketTable th:nth-child(2),
  #ticketTable th:nth-child(3),
  #ticketTable td:nth-child(2),
  #ticketTable td:nth-child(3) {
    width: 80px;
    text-align: right;
  }

  #ticketTable td:nth-child(4),
  #ticketTable th:nth-child(4) {
    width: 90px;
    text-align: right;
  }
    .lr-right .ticket {
      border: 2px solid #dfe3e8;
      border-radius: 10px;
      padding: 20px;
      background: #fff;
      height: 100%;
  }

  /* Give the entire right side a full vertical border container */
  .lr-right {
      border: 2px solid #dfe3e8;
      border-radius: 12px;
      padding: 20px;
      background: #fafbfc;
  }

  /* Fix left panel border so both sides match */
  .lr-left {
      border: 2px solid #dfe3e8;
      border-radius: 12px;
      padding: 20px;
      background: #fff;
  }
   /* LEFT PANEL – product grid */
  .lr-left {
      border: 1px solid #dfe3e8;
      border-radius: 12px;
      padding: 16px;
      background: #ffffff;
  }

  /* RIGHT PANEL – whole ticket side */
  .lr-right {
      border: 1px solid #dfe3e8;
      border-radius: 12px;
      padding: 16px;
      background: #ffffff;
      overflow-x: auto;      /* avoid weird overflow if table wider */
  }

  /* Inner ticket: remove extra border so we don't see "box inside box" */
  .lr-right .ticket {
      border: none;          /* remove our previous 2px border */
      border-radius: 0;
      padding: 0;
      background: transparent;
      width: 100%;
  }

  /* Optional: tighten table so it stays inside nicely */
  #ticketTable {
      margin-bottom: 0.75rem;
      width: 100%;
  }
  .pos-wrapper {
    display: flex;
    gap: 25px;
    align-items: flex-start;
    justify-content: space-between;
    width: 100%;
}

/* LEFT SIDE (Product Grid) */
.pos-left {
    width: 45%;
    min-width: 420px;
    border: 1px solid #dfe3e8;
    border-radius: 12px;
    padding: 16px;
    background: #fff;
    box-sizing: border-box;
}

/* RIGHT SIDE (Ticket / Checkout) */
.pos-right {
    width: 55%;
    min-width: 420px;
    /* No border */
    padding: 0;
    background: transparent;
    box-sizing: border-box;
}

/* Ticket container should fully match right width */
.pos-right .ticket {
    width: 100%;
    max-width: 100%;
    background: #fff;
    padding: 16px;
    border-radius: 12px;
    border: 1px solid #ddd;
}

/* Prevent stacking – force same row table */
#ticketTable {
    width: 100%;
    table-layout: fixed;
}

#ticketTable th:first-child,
#ticketTable td:first-child {
    width: 45%; 
    white-space: normal;
}

#ticketTable td,
#ticketTable th {
    vertical-align: middle;
    white-space: nowrap;
}

/* Handles long remove button placement */
#ticketTable td:last-child {
    width: 80px;
}
/* Give Disc column more width */
#ticketTable th:nth-child(3),
#ticketTable td:nth-child(3) {
    width: 120px !important;
    white-space: nowrap;
}

/* Give Total column fixed width */
#ticketTable th:nth-child(4),
#ticketTable td:nth-child(4) {
    width: 110px !important;
    white-space: nowrap;
}

/* Adjust the inner discount input group so it never squishes */
#ticketTable .input-group {
    min-width: 110px !important;
    justify-content: flex-end;
}
.lr-right {
    flex: 0 0 62% !important;
    max-width: 62% !important;
}
.lr-left {
    flex: 0 0 38% !important;
    max-width: 38% !important;
}

</style>

<div class="lr-top">

  <div>
    <h4 class="mb-0">Sale (IN)</h4>
  </div>
  <div class="text-end">
    <?php if ($msg): ?><div class="alert alert-info small mb-0"><?= h($msg) ?></div><?php endif; ?>
  </div>
</div>

<!-- 💡 New Layout: Custom Flex POS Split -->
<<div class="pos-wrapper">
  
  <!-- Left Side (Product Grid Area) -->
  <div class="pos-left">
    <div class="pos-top-card">
      <div class="d-flex mb-2 align-items-center">
        <input id="productSearch" class="form-control me-2" placeholder="Search product code or name..." style="flex:1;">
        <div>
          <div class="btn-group" role="group" aria-label="Sale Mode">
            <button type="button" class="btn btn-sm btn-outline-primary active" data-mode="retail" id="btnRetail">Retail</button>
            <button type="button" class="btn btn-sm btn-outline-primary" data-mode="wholesale" id="btnWholesale">Wholesale</button>
          </div>
        </div>
      </div>

      <div class="lr-cats" id="categoriesBar">
        <label for="categorySelect" class="">Category:</label>
        <select id="categorySelect" class="form-select form-select-sm" style="max-width:300px;">
          <option value="">All Categories</option>
          <?php foreach ($categories as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div id="productGrid" class="product-grid" style="margin-top:12px;">
      <!-- JS renders tiles -->
    </div>
  </div>

  <!-- Right Side (Ticket / Checkout) -->
  <div class="pos-right">
    <div class="ticket">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div>
          <div class="small-muted">Customer</div>
          <select class="form-select form-select-sm" id="ticketCustomer">
            <option value="">— walk-in —</option>
            <?php foreach ($customers as $c): ?>
              <option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="text-end">
          <div class="small-muted">Date</div>
          <input type="date" id="ticketDate" class="form-control form-control-sm" value="<?= h(date('Y-m-d')) ?>">
        </div>
      </div>

      <table class="table table-sm mb-2" id="ticketTable">
        <thead>
          <tr>
            <th>Item</th>
            <th class="text-end">Qty</th>
            <th class="text-end">Disc</th>
            <th class="text-end">Total</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="ticketBody">
          <tr><td colspan="5" class="text-muted small">No items</td></tr>
        </tbody>
      </table>

      <div class="mb-1 small-muted">Invoice Discount</div>
      <div class="d-flex gap-2 align-items-center mb-2">
        <select id="invDiscountType" class="form-select form-select-sm" style="width:110px;">
          <option value="">— none —</option>
          <option value="percent">Percent (%)</option>
          <option value="amount">Amount (₱)</option>
        </select>
        <input id="invDiscountValue" type="number" step="0.01" class="form-control form-control-sm" placeholder="Value" style="width:120px;">
        <div class="ms-auto text-end">
          <div class="small-muted">Subtotal</div>
          <div id="ticketSubtotal" class="fs-6">₱0.00</div>
        </div>
      </div>

      <div class="d-flex justify-content-between align-items-center">
        <div class="small-muted">Total Discounts</div>
        <div id="ticketDiscountTotal" class="fw-bold">₱0.00</div>
      </div>

      <div class="d-flex justify-content-between align-items-center mt-2">
        <div class="fs-5">Grand Total</div>
        <div id="ticketGrandTotal" class="fs-4">₱0.00</div>
      </div>

      <div class="d-grid gap-2 mt-3">
        <!--<button id="btnPay" type="button" class="btn btn-loy">Pay</button>-->
        <button id="btnSaveTicket" class="btn btn-outline-secondary">Save Ticket</button>
        <button id="btnSaveSale" class="btn btn-primary">Save Sale</button>
      </div>
    </div>

    <div class="mt-3">
      <h6 class="mb-2">Saved Tickets</h6>
      <?php if (empty($_SESSION['tickets'])): ?>
        <div class="text-muted small">No tickets</div>
      <?php else: ?>
        <ul class="list-group small">
          <?php foreach (array_reverse($_SESSION['tickets']) as $t): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <div><strong><?= h($t['id']) ?></strong></div>
                <div class="small-muted"><?= h(date('Y-m-d H:i', strtotime($t['created_at']))) ?> · <?= (int)count($t['items']) ?> items</div>
              </div>
              <div class="btn-group-vertical">
                <a class="btn btn-sm btn-outline-primary" href="sale_add.php?load_ticket=<?= urlencode($t['id']) ?>">Load</a>
                <a class="btn btn-sm btn-outline-danger" href="sale_add.php?delete_ticket=<?= urlencode($t['id']) ?>" onclick="return confirm('Delete ticket?')">Del</a>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- Hidden form to POST Save Ticket / Save Sale -->
<form id="hiddenPostForm" method="post" style="display:none;">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <input type="hidden" name="action" id="hidden_action" value="save_sale">
  <input type="hidden" name="customer_id" id="hidden_customer">
  <input type="hidden" name="date" id="hidden_date">
  <input type="hidden" name="notes" id="hidden_notes">
  <input type="hidden" name="sale_mode" id="hidden_sale_mode" value="retail">
  <input type="hidden" name="inv_discount_type" id="hidden_inv_discount_type">
  <input type="hidden" name="inv_discount_value" id="hidden_inv_discount_value">
  <div id="hidden_items"></div>
</form>

<!-- Pay Modal (simple) -->
<div class="modal fade" id="payModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog pay-modal">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Payment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>Total: <strong id="payTotal">₱0.00</strong></div>
        <div class="mt-3">
          <label>Amount Received</label>
          <input id="payReceived" type="number" step="0.01" class="form-control" value="">
        </div>
        <div class="mt-2 small-muted">Change: <span id="payChange">₱0.00</span></div>
      </div>
      <div class="modal-footer">
        <button id="payCancel" type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button id="payConfirm" type="button" class="btn btn-loy">Confirm & Save Sale</button>
      </div>
    </div>
  </div>
</div>

<!-- bootstrap JS assumed already present in footer -->
<script>
const PRODUCTS = <?= json_encode($products, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
const CATEGORIES = <?= json_encode($categories, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
// build category name + color maps (auto-pick pastel colors)
const CATEGORY_COLORS = {};
const CATEGORY_NAMES = {};
(function(){
  const palette = ['#1e88e5','#43a047','#fb8c00','#e91e63','#6a1b9a','#00acc1','#fdd835','#8d6e63'];
  for (let i = 0; i < CATEGORIES.length; i++) {
    const c = CATEGORIES[i];
    const id = String(c.id);
    CATEGORY_NAMES[id] = c.name;
    CATEGORY_COLORS[id] = palette[i % palette.length];
  }
  CATEGORY_COLORS['default'] = '#6c757d';
})();
const initialItems = <?= json_encode($initialItems, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
const initialTicket = <?= json_encode($initialTicket ?? null, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;

let currentMode = 'retail';
let cart = []; // array of {product_id, code, name, qty, unit_price, sold_by, unit, price_tier, discount_type, discount_value}

/* helpers */
function money(n){ return '₱' + Number(n || 0).toFixed(2); }
function priceFor(prod, mode){ if (!prod) return 0; if (mode==='wholesale'){ const w = parseFloat(prod.wholesale_price); return (w>0 ? w : parseFloat(prod.sell_price||0)); } return parseFloat(prod.sell_price||0); }
function fmtStock(q){ const n = parseFloat(q||0); return (n%1===0 ? n.toFixed(0) : n.toFixed(3).replace(/\.?0+$/,'')); }

/* Product Grid rendering */
const productGrid = document.getElementById('productGrid');
const productSearch = document.getElementById('productSearch');
let activeCategory = '';

function renderProducts(){
  productGrid.innerHTML = '';
  const q = (productSearch.value || '').trim().toLowerCase();
  for (const p of PRODUCTS) {
    if (activeCategory && String(p.category_id) !== String(activeCategory)) continue;
    if (q) {
      const hay = (p.name + ' ' + p.code).toLowerCase();
      if (!hay.includes(q)) continue;
    }
    const price = priceFor(p, currentMode);
    const card = document.createElement('div');
    card.className = 'product-card';
    card.dataset.id = p.id;
    // small category icon (colored) + product info
const cid = p.category_id !== undefined && p.category_id !== null ? String(p.category_id) : 'default';
const catColor = CATEGORY_COLORS[cid] || CATEGORY_COLORS['default'];
const catName = CATEGORY_NAMES[cid] || '';
const initial = (catName && catName.length) ? catName.trim().charAt(0).toUpperCase() : '';
card.innerHTML = `
  <div style="position:relative;">
    <div class="cat-icon" title="${catName}" style="background:${catColor};">${initial}</div>
    <div style="padding-left:44px;">
      <div class="product-title">${p.code} — ${p.name}</div>
      <div class="product-meta">${fmtStock(p.stock_qty)} ${p.unit || 'pc'}</div>
    </div>
  </div>
  <div style="text-align:right">
    <div class="fw-bold">${money(price)}</div>
    <div class="product-meta">${p.sold_by === 'weight' ? (p.unit || 'kg') : 'pc'}</div>
  </div>`;

    card.addEventListener('click', ()=> onAddProduct(p));
    productGrid.appendChild(card);
  }
  if (!productGrid.children.length) {
    const note = document.createElement('div');
    note.className = 'text-muted';
    note.textContent = 'No products found.';
    productGrid.appendChild(note);
  }
}

/* Category dropdown */
const categorySelect = document.getElementById('categorySelect');
if (categorySelect) {
  categorySelect.addEventListener('change', () => {
    activeCategory = categorySelect.value || '';
    renderProducts();
  });
}

/* Search */
productSearch.addEventListener('input', ()=> renderProducts());

/* Add product to cart */
function onAddProduct(p){
  let qty = 1;
  if (p.sold_by === 'weight') {
    const val = prompt(`Enter weight in ${p.unit || 'kg'} (e.g. 0.25, 0.5, 1):`, '0.5');
    if (val === null) return;
    qty = parseFloat(val);
    if (isNaN(qty) || qty <= 0) { alert('Invalid quantity'); return; }
    // normalize to quarter kilo client-side
    qty = Math.max(0.25, Math.round(qty * 4) / 4);
  }
  const unitPrice = priceFor(p, currentMode);
  const found = cart.find(x => x.product_id == p.id && x.unit_price == unitPrice && x.discount_type==null && x.discount_value==null);
  if (found) found.qty = Number(found.qty) + Number(qty);
  else cart.push({
    product_id: p.id,
    code: p.code,
    name: p.name,
    qty: Number(qty),
    unit_price: Number(unitPrice),
    sold_by: p.sold_by,
    unit: p.unit || 'pc',
    price_tier: currentMode,
    discount_type: null,
    discount_value: null
  });
  renderTicket();
}

/* render ticket */
function renderTicket(){
  const tbody = document.getElementById('ticketBody');
  tbody.innerHTML = '';
  if (!cart.length) { tbody.innerHTML = '<tr><td colspan="5" class="text-muted small">No items</td></tr>'; updateTotals(); return; }
  let subtotal = 0;
  cart.forEach((it, idx) => {
    const gross = Number(it.qty) * Number(it.unit_price);
    const lineDisc = calcLineDiscount(gross, it.discount_type, it.discount_value);
    const lineNet = Math.max(0, gross - lineDisc);
    subtotal += lineNet;

    const tr = document.createElement('tr');
    tr.innerHTML = `<td>
                      <div class="fw-bold">${it.code} — ${it.name}</div>
                      <div class="small-muted">${it.sold_by==='weight'? it.qty + ' ' + it.unit : (parseInt(it.qty) + ' pc')}</div>
                    </td>
                    <td class="text-end">
                      <input data-idx="${idx}" class="form-control form-control-sm qty-input" type="number" value="${it.qty}"
                             step="${it.sold_by==='weight'? '0.25':'1'}" min="${it.sold_by==='weight'? '0.25':'1'}" style="width:90px;margin-left:auto;">
                    </td>
                    <td class="text-end">
                      <select data-idx="${idx}" class="form-select form-select-sm disc-select" title="Discount Type">
                        <option value="" ${it.discount_type===null||it.discount_type===''?'selected':''}>—</option>
                        <option value="percent" ${it.discount_type==='percent'?'selected':''}>%</option>
                        <option value="amount" ${it.discount_type==='amount'?'selected':''}>₱</option>
                      </select>
                      <input data-idx="${idx}" class="form-control form-control-sm disc-input" type="number" step="0.01" min="0"
                             value="${it.discount_value!==null?it.discount_value:''}" placeholder="val">
                      <div class="line-disc">${money(lineDisc)}</div>
                    </td>
                    <td class="text-end">${money(lineNet)}</td>
                    <td class="text-end"><button class="btn btn-sm btn-outline-danger btn-remove" data-idx="${idx}">Remove</button></td>`;
    tbody.appendChild(tr);
  });

  // wire qty inputs, discount selectors and remove
  tbody.querySelectorAll('.qty-input').forEach(inp=>{
    inp.addEventListener('change', ()=>{
      const i = Number(inp.dataset.idx);
      let v = parseFloat(inp.value || 0);
      if (isNaN(v) || v <= 0) v = 0;
      if (cart[i].sold_by !== 'weight') v = Math.max(1, Math.round(v));
      else v = Math.max(0.25, Math.round(v * 4) / 4);
      cart[i].qty = v;
      renderTicket();
    });
  });
  tbody.querySelectorAll('.disc-select').forEach(sel=>{
    sel.addEventListener('change', ()=>{
      const i = Number(sel.dataset.idx);
      cart[i].discount_type = sel.value || null;
      // if cleared, nullify value as well
      if (!sel.value) cart[i].discount_value = null;
      renderTicket();
    });
  });
  tbody.querySelectorAll('.disc-input').forEach(inp=>{
    inp.addEventListener('input', ()=>{
      const i = Number(inp.dataset.idx);
      const v = inp.value === '' ? null : parseFloat(inp.value);
      cart[i].discount_value = (v === null || isNaN(v)) ? null : v;
      renderTicket();
    });
  });
  tbody.querySelectorAll('.btn-remove').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const i = Number(btn.dataset.idx);
      cart.splice(i,1);
      renderTicket();
    });
  });

  // set invoice discount UI from current (if loaded ticket)
  if (initialTicket) {
    // handled in init()
  }

  updateTotals();
}

function calcLineDiscount(gross, dt, dv){
  gross = Number(gross) || 0;
  if (!dt || dv === null || dv === '' || typeof dv === 'undefined') return 0;
  if (dt === 'percent') return Math.max(0, gross * (Math.max(0, Math.min(100, Number(dv))) / 100));
  if (dt === 'amount')  return Math.max(0, Number(dv));
  return 0;
}

function updateTotals(){
  let subtotal = 0;
  let lineDiscounts = 0;
  cart.forEach(it=>{
    const gross = Number(it.qty) * Number(it.unit_price);
    const ld = calcLineDiscount(gross, it.discount_type, it.discount_value);
    const net = Math.max(0, gross - ld);
    subtotal += net;
    lineDiscounts += ld;
  });

  // invoice discount
  const invType = document.getElementById('invDiscountType').value;
  const invVal  = (document.getElementById('invDiscountValue').value || '') === '' ? null : parseFloat(document.getElementById('invDiscountValue').value);
  let invAlloc = 0;
  if (invType && invVal !== null && !isNaN(invVal)) {
    if (invType === 'percent') invAlloc = subtotal * (Math.max(0, Math.min(100, invVal))/100);
    if (invType === 'amount')  invAlloc = Math.max(0, invVal);
  }

  const totalDiscounts = lineDiscounts + invAlloc;
  const grand = Math.max(0, subtotal - invAlloc);

  document.getElementById('ticketSubtotal').textContent = money(subtotal);
  document.getElementById('ticketDiscountTotal').textContent = money(totalDiscounts);
  document.getElementById('ticketGrandTotal').textContent = money(grand);
  document.getElementById('payTotal').textContent = money(grand);
  document.getElementById('ticketTotal') && (document.getElementById('ticketTotal').textContent = money(grand));
}

document.getElementById('invDiscountType').addEventListener('change', updateTotals);
document.getElementById('invDiscountValue').addEventListener('input', updateTotals);

/* sale mode toggle */
function setMode(mode){
  currentMode = mode;
  document.getElementById('hidden_sale_mode').value = mode;
  document.getElementById('sale_mode')?.value && (document.getElementById('sale_mode').value = mode);
  document.querySelectorAll('[data-mode]').forEach(b=>{
    const active = b.dataset.mode === mode;
    b.classList.toggle('active', active);
    b.classList.toggle('btn-primary', active);
    b.classList.toggle('btn-outline-primary', !active);
  });
  renderProducts();
}
document.getElementById('btnRetail').addEventListener('click', ()=> setMode('retail'));
document.getElementById('btnWholesale').addEventListener('click', ()=> setMode('wholesale'));

/* Save Ticket / Save Sale wiring */
document.getElementById('btnSaveTicket').addEventListener('click', ()=> {
  if (!cart.length) { alert('No items to save'); return; }
  buildAndSubmit('save_ticket');
});

document.getElementById('btnSaveSale').addEventListener('click', ()=> {
  if (!cart.length) { alert('No items to save'); return; }
  const payModal = new bootstrap.Modal(document.getElementById('payModal'));
  document.getElementById('payReceived').value = '';
  document.getElementById('payChange').textContent = money(0);
  document.getElementById('payTotal').textContent = document.getElementById('ticketGrandTotal').textContent;
  payModal.show();
});

/* Pay modal logic */
document.getElementById('payReceived').addEventListener('input', ()=>{
  const rec = parseFloat(document.getElementById('payReceived').value || 0);
  const total = parseFloat((document.getElementById('ticketGrandTotal').textContent || '₱0').replace(/[^0-9.-]+/g,"")) || 0;
  const change = Math.max(0, rec - total);
  document.getElementById('payChange').textContent = money(change);
});

document.getElementById('payConfirm').addEventListener('click', ()=>{
  buildAndSubmit('save_sale');
});

/* Build hidden form and submit */
function buildAndSubmit(action){
  const hidden = document.getElementById('hidden_items');
  hidden.innerHTML = '';
  document.getElementById('hidden_action').value = action;
  document.getElementById('hidden_customer').value = document.getElementById('ticketCustomer').value || '';
  document.getElementById('hidden_date').value = document.getElementById('ticketDate').value || '';
  document.getElementById('hidden_notes').value = ''; // you can add a notes input if needed
  document.getElementById('hidden_sale_mode').value = currentMode;
  document.getElementById('hidden_inv_discount_type').value = document.getElementById('invDiscountType').value || '';
  document.getElementById('hidden_inv_discount_value').value = document.getElementById('invDiscountValue').value || '';

  cart.forEach((it, idx) => {
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][product_id]" value="${encodeURIComponent(it.product_id)}">`);
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][qty]" value="${encodeURIComponent(it.qty)}">`);
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][unit_price]" value="${encodeURIComponent(it.unit_price)}">`);
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][price_tier]" value="${encodeURIComponent(it.price_tier)}">`);
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][discount_type]" value="${encodeURIComponent(it.discount_type ?? '')}">`);
    hidden.insertAdjacentHTML('beforeend', `<input type="hidden" name="items[${idx}][discount_value]" value="${encodeURIComponent(it.discount_value ?? '')}">`);
  });

  // submit hidden form
  document.getElementById('hiddenPostForm').submit();
}

/* initial load */
(function init(){
  // populate cart from loaded ticket or nothing
  if (initialItems && initialItems.length) {
    cart = initialItems.map(it=>({
      product_id: it.product_id,
      code: (PRODUCTS.find(p=>p.id==it.product_id)||{}).code||'',
      name: (PRODUCTS.find(p=>p.id==it.product_id)||{}).name||'',
      qty: isNaN(parseFloat(it.qty)) ? 1 : parseFloat(it.qty),
      unit_price: parseFloat(it.unit_price) || 0,
      sold_by: (PRODUCTS.find(p=>p.id==it.product_id)||{}).sold_by || 'each',
      unit: (PRODUCTS.find(p=>p.id==it.product_id)||{}).unit || 'pc',
      price_tier: it.price_tier || 'retail',
      discount_type: it.discount_type ?? null,
      discount_value: (typeof it.discount_value !== 'undefined' && it.discount_value !== null) ? it.discount_value : null
    }));
    // set customer/date and invoice discount if present server-side
    <?php if ($initialTicket): ?>
      document.getElementById('ticketCustomer').value = '<?= h($initialTicket['customer_id'] ?? '') ?>';
      document.getElementById('ticketDate').value = '<?= h($initialTicket['date'] ?? date('Y-m-d')) ?>';
      setMode('<?= h($initialTicket['sale_mode'] ?? 'retail') ?>');
      // invoice discount (if ticket stored it)
      <?php if (isset($initialTicket['inv_discount_type'])): ?>
        document.getElementById('invDiscountType').value = '<?= h($initialTicket['inv_discount_type']) ?>';
      <?php endif; ?>
      <?php if (isset($initialTicket['inv_discount_value'])): ?>
        document.getElementById('invDiscountValue').value = '<?= h($initialTicket['inv_discount_value']) ?>';
      <?php endif; ?>
    <?php endif; ?>
  }
  renderProducts();
  renderTicket();
})();
</script>

<?php require_once __DIR__.'/../includes/footer.php'; ?>
