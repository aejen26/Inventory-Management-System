<?php
require_once __DIR__.'/../includes/header.php';
require_login();
$pdo = getDB();

/* ---------- Dates ---------- */
$today        = date('Y-m-d');
$monthStart   = date('Y-m-01');
$sevenDaysAgo = date('Y-m-d', strtotime('-7 days'));
$thirtyAgo    = date('Y-m-d', strtotime('-29 days')); // 30 points incl today

/* ---------- Helpers ---------- */
$lineNetExpr = "GREATEST(
  0,
  (ti.qty * ti.unit_price) -
  CASE
    WHEN ti.discount_type='percent' AND ti.discount_value IS NOT NULL
      THEN (ti.qty * ti.unit_price) * (ti.discount_value/100)
    WHEN ti.discount_type='amount'  AND ti.discount_value IS NOT NULL
      THEN ti.discount_value
    ELSE 0
  END
)";

/* ---------- KPIs ---------- */
$totalProducts = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1")->fetchColumn();
$totalUnits    = (int)$pdo->query("SELECT COALESCE(SUM(stock_qty),0) FROM products WHERE is_active=1")->fetchColumn();
$lowCount = 0; try { $lowCount = get_low_stock_count($pdo); } catch (Throwable $e) { $lowCount = 0; }

$st = $pdo->prepare("
  SELECT COALESCE(SUM($lineNetExpr),0) FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='sale' AND t.date = ?
"); $st->execute([$today]); $salesToday = (float)$st->fetchColumn();

$st = $pdo->prepare("
  SELECT COALESCE(SUM($lineNetExpr),0) FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='sale' AND t.date BETWEEN ? AND ?
"); $st->execute([$monthStart, $today]); $salesMonth = (float)$st->fetchColumn();

$st = $pdo->prepare("
  SELECT COALESCE(SUM($lineNetExpr),0) FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='purchase' AND t.date = ?
"); $st->execute([$today]); $purchasesToday = (float)$st->fetchColumn();

$st = $pdo->prepare("
  SELECT COALESCE(SUM($lineNetExpr),0) FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='purchase' AND t.date BETWEEN ? AND ?
"); $st->execute([$monthStart, $today]); $purchasesMonth = (float)$st->fetchColumn();

/* ---------- Recent movements (last 10) ---------- */
$rows = $pdo->query("
  SELECT
    t.id, t.type, t.ref_no, t.date, t.created_at,
    u.name AS user_name,
    s.name AS supplier_name,
    c.name AS customer_name,
    COUNT(ti.id) AS line_count,
    SUM(ti.qty)  AS qty_total,
    SUM($lineNetExpr) AS net_value
  FROM transactions t
  JOIN users u              ON u.id = t.user_id
  LEFT JOIN suppliers s     ON s.id = t.supplier_id
  LEFT JOIN customers c     ON c.id = t.customer_id
  JOIN transaction_items ti ON ti.transaction_id = t.id
  GROUP BY t.id, t.type, t.ref_no, t.date, t.created_at, u.name, s.name, c.name
  ORDER BY t.date DESC, t.id DESC
  LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Low stock (top 10) ---------- */
$globalLow = (int)get_setting($pdo,'low_stock_default',5);
$lowRows = $pdo->prepare("
  SELECT id, code, name, stock_qty, COALESCE(low_stock_threshold, ?) AS threshold
  FROM products
  WHERE is_active=1 AND stock_qty < COALESCE(low_stock_threshold, ?)
  ORDER BY stock_qty ASC, name ASC
  LIMIT 10
"); $lowRows->execute([$globalLow, $globalLow]); $lowList = $lowRows->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Top sellers last 7 days ---------- */
$top = $pdo->prepare("
  SELECT p.code, p.name, SUM(ti.qty) AS qty_sold, SUM($lineNetExpr) AS amount
  FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  JOIN products p           ON p.id = ti.product_id
  WHERE t.type='sale' AND t.date BETWEEN ? AND ?
  GROUP BY p.id, p.code, p.name
  ORDER BY qty_sold DESC, amount DESC
  LIMIT 5
"); $top->execute([$sevenDaysAgo, $today]); $topItems = $top->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Sparkline data: last 30 days Sales & Purchases ---------- */
$labels = []; $sales30 = []; $purch30 = []; $mapSales = []; $mapPurch = [];
for ($d = strtotime($thirtyAgo); $d <= strtotime($today); $d = strtotime('+1 day', $d)) {
  $key = date('Y-m-d', $d);
  $labels[] = date('M j', $d);
  $mapSales[$key] = 0.0;
  $mapPurch[$key] = 0.0;
}
$sp = $pdo->prepare("
  SELECT t.date AS d, COALESCE(SUM($lineNetExpr),0) AS amt
  FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='sale' AND t.date BETWEEN ? AND ?
  GROUP BY t.date
"); $sp->execute([$thirtyAgo, $today]);
foreach ($sp as $r) { $k = $r['d']; if (isset($mapSales[$k])) $mapSales[$k] = (float)$r['amt']; }

$pp = $pdo->prepare("
  SELECT t.date AS d, COALESCE(SUM($lineNetExpr),0) AS amt
  FROM transactions t
  JOIN transaction_items ti ON ti.transaction_id=t.id
  WHERE t.type='purchase' AND t.date BETWEEN ? AND ?
  GROUP BY t.date
"); $pp->execute([$thirtyAgo, $today]);
foreach ($pp as $r) { $k = $r['d']; if (isset($mapPurch[$k])) $mapPurch[$k] = (float)$r['amt']; }

$sales30 = array_values($mapSales);
$purch30 = array_values($mapPurch);
?>
<!-- KPI cards -->
<div class="row g-3 mb-3">
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="text-muted small">Products</div>
      <div class="fs-4 fw-semibold"><?= number_format($totalProducts) ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="text-muted small">Stocks on Hand</div>
      <div class="fs-4 fw-semibold"><?= number_format($totalUnits) ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <div class="text-muted small">Sales (This Month)</div>
          <div class="fs-5 fw-semibold mb-2">₱<?= number_format($salesMonth,2) ?></div>
        </div>
        <div style="width:160px; height:60px;"><canvas id="mtSparkSales" width="160" height="60"></canvas></div>
      </div>
      <div class="text-muted small">Today: ₱<?= number_format($salesToday,2) ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <div class="text-muted small">Purchases (This Month)</div>
          <div class="fs-5 fw-semibold mb-2">₱<?= number_format($purchasesMonth,2) ?></div>
        </div>
        <div style="width:160px; height:60px;"><canvas id="mtSparkPurch" width="160" height="60"></canvas></div>
      </div>
      <div class="text-muted small">Today: ₱<?= number_format($purchasesToday,2) ?></div>
    </div>
  </div>
</div>

<!-- Secondary strip -->
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="p-3 border rounded">
      <div class="text-muted small">Low-Stock Alerts</div>
      <div class="fs-5"><?= (int)$lowCount ?> item(s)</div>
    </div>
  </div>
  <div class="col-md-9 d-flex gap-2 align-items-stretch">
    <a href="/profitradar/public/sale_add.php" class="btn btn-primary flex-fill">+ New Sale</a>
    <a href="/profitradar/public/purchase_add.php" class="btn btn-outline-primary flex-fill">+ New Purchase</a>
    <a href="/profitradar/public/products.php" class="btn btn-outline-secondary flex-fill">Products</a>
    <a href="/profitradar/public/low_stock.php" class="btn btn-outline-danger flex-fill">Low Stock</a>
  </div>
</div>

<div class="row g-3">
  <!-- Recent Movements -->
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Recent Movements</strong>
        <a href="/profitradar/public/transactions.php" class="small">View all</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm mb-0 align-middle">
          <thead>
            <tr>
              <th>Date/Time</th>
              <th>Type</th>
              <th>Ref</th>
              <th>Customer</th>
              <th class="text-end">Lines</th>
              <th class="text-end">Qty</th>
              <th class="text-end">Net Value</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="7" class="text-muted">No movements yet.</td></tr>
            <?php else: ?>
              <?php foreach ($rows as $t):
                $dtRaw  = $t['created_at'] ?: $t['date'];
                $dtDisp = $dtRaw ? date('Y-m-d H:i', strtotime($dtRaw)) : '';
                $partner = $t['type']==='purchase' ? ($t['supplier_name'] ?? '—') : ($t['customer_name'] ?? '— walk-in —');
                $badge = $t['type']==='purchase' ? '<span class="badge bg-success">IN</span>' : '<span class="badge bg-danger">OUT</span>';
              ?>
                <tr>
                  <td><?= h($dtDisp) ?></td>
                  <td><?= $badge ?> <span class="ms-1"><?= h(ucfirst($t['type'])) ?></span></td>
                  <td><?= h($t['ref_no']) ?></td>
                  <td><?= h($partner) ?></td>
                  <td class="text-end"><?= (int)$t['line_count'] ?></td>
                  <td class="text-end"><?= (int)$t['qty_total'] ?></td>
                  <td class="text-end">₱<?= number_format((float)$t['net_value'],2) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Low Stock & Top Sellers -->
  <div class="col-lg-5 d-flex flex-column gap-3">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Low Stock</strong>
        <a href="/profitradar/public/low_stock.php" class="small">Manage</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm mb-0 align-middle">
          <thead>
            <tr>
              <th>Code</th>
              <th>Item</th>
              <th class="text-center">Qty</th>
              <th class="text-center">Min</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$lowList): ?>
              <tr><td colspan="4" class="text-muted">No low-stock items 🎉</td></tr>
            <?php else: ?>
              <?php foreach ($lowList as $p): ?>
                <tr class="table-warning">
                  <td><?= h($p['code']) ?></td>
                  <td><?= h($p['name']) ?></td>
                  <td class="text-center"><?= (int)$p['stock_qty'] ?></td>
                  <td class="text-center"><?= (int)$p['threshold'] ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><strong>Top Sellers (Last 7 Days)</strong></div>
      <div class="table-responsive">
        <table class="table table-sm mb-0 align-middle">
          <thead>
            <tr>
              <th>Code</th>
              <th>Item</th>
              <th class="text-end">Qty</th>
              <th class="text-end">Amount</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$topItems): ?>
              <tr><td colspan="4" class="text-muted">No sales in the last 7 days.</td></tr>
            <?php else: ?>
              <?php foreach ($topItems as $it): ?>
                <tr>
                  <td><?= h($it['code']) ?></td>
                  <td><?= h($it['name']) ?></td>
                  <td class="text-end"><?= (int)$it['qty_sold'] ?></td>
                  <td class="text-end">₱<?= number_format((float)$it['amount'],2) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<!-- Combined Sales vs Purchases (last 30 days) -->
<div class="card mt-3">
  <div class="card-header"><strong>Sales vs Purchases (Last 30 Days)</strong></div>
  <div class="p-3" style="height:220px;">
    <canvas id="bar30" width="600" height="200"></canvas>
  </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function(){
  const labels   = <?= json_encode($labels) ?>;
  const sales30  = <?= json_encode($sales30) ?>;
  const purch30  = <?= json_encode($purch30) ?>;

  // Minimal line sparkline (sales)
  const s1 = document.getElementById('mtSparkSales');
  if (s1) new Chart(s1, {
    type: 'line',
    data: { labels, datasets: [{ data: sales30, borderWidth: 2, pointRadius: 0, tension: .35, fill: false }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}, tooltip:{mode:'index',intersect:false}}, scales:{x:{display:false}, y:{display:false}} }
  });

  // Minimal line sparkline (purchases)
  const s2 = document.getElementById('mtSparkPurch');
  if (s2) new Chart(s2, {
    type: 'line',
    data: { labels, datasets: [{ data: purch30, borderWidth: 2, pointRadius: 0, tension: .35, fill: false }] },
    options: { responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}, tooltip:{mode:'index',intersect:false}}, scales:{x:{display:false}, y:{display:false}} }
  });

  // Combined bars (Sales vs Purchases)
  const b = document.getElementById('bar30');
  if (b) new Chart(b, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Sales',     data: sales30 },
        { label: 'Purchases', data: purch30 }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'top' } },
      scales: {
        x: { stacked: false, ticks: { maxTicksLimit: 10 } },
        y: { stacked: false, beginAtZero: true }
      }
    }
  });
})();
</script>

<?php require_once __DIR__.'/../includes/footer.php'; ?>
