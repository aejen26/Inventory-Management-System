<?php
ob_start();
require_once __DIR__.'/../includes/header.php';
require_login();
$pdo = getDB();

/* ---------------------- Helper: format stock with unit --------------------- */
/**
 * Format product stock with unit:
 *  - weight products: show decimals nicely (trim trailing zeros) + unit (kg etc.)
 *  - each products: show integer + "pc"
 */
function fmt_stock($stock, $sold_by = 'each', $unit = '') {
  // ensure numeric
  $v = is_null($stock) ? 0.0 : (float)$stock;

  if ($sold_by === 'weight') {
    // prefer 2 decimals for quarter/half increments, otherwise up to 3, trimming zeros
    if (fmod($v, 1.0) === 0.0) {
      // whole number
      $out = number_format($v, 0);
    } elseif (fmod($v * 100, 1) === 0.0) {
      // exact to 2 decimals
      $out = rtrim(rtrim(number_format($v, 2, '.', ''), '0'), '.');
    } else {
      // fallback to 3 decimals
      $out = rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.');
    }
    $unitLabel = $unit ?: 'kg';
    return h($out) . ' ' . h($unitLabel);
  }

  // per-piece: show integer pcs (floor to be safe)
  return number_format((int)floor($v)) . ' pc';
}
/* -------------------------------------------------------------------------- */

/* Filters */
$q       = trim($_GET['q'] ?? '');
$catId   = trim($_GET['category_id'] ?? '');
$supId   = trim($_GET['supplier_id'] ?? '');
$locId   = trim($_GET['location_id'] ?? '');

/* Query
   NOTE: p.* will include sold_by and unit if present in your schema.
*/
$sql = "SELECT p.*,
               s.name AS supplier_name,
               c.name AS category_name,
               l.name AS location_name
        FROM products p
        LEFT JOIN suppliers  s ON s.id = p.supplier_id
        LEFT JOIN categories c ON c.id = p.category_id
        LEFT JOIN locations  l ON l.id = p.location_id
        WHERE p.is_active = 1";
$params = [];

/* Text search: code, name, supplier, category, location, price */
if ($q !== '') {
  $qLike = '%'.$q.'%';
  $sql .= " AND (
              p.code LIKE ? OR
              p.name LIKE ? OR
              s.name LIKE ? OR
              c.name LIKE ? OR
              l.name LIKE ? OR
              CAST(p.sell_price AS CHAR) LIKE ?
            )";
  array_push($params, $qLike,$qLike,$qLike,$qLike,$qLike,$qLike);
}

/* ID filters */
if ($catId !== '') { $sql .= " AND p.category_id = ?";  $params[] = (int)$catId; }
if ($supId !== '') { $sql .= " AND p.supplier_id = ?";  $params[] = (int)$supId; }
if ($locId !== '') { $sql .= " AND p.location_id = ?";  $params[] = (int)$locId; }

$sql .= " ORDER BY p.name ASC LIMIT 200";
$st = $pdo->prepare($sql);
$st->execute($params);

/* Dropdown data */
$cats = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
$sups = $pdo->query("SELECT id, name FROM suppliers  ORDER BY name")->fetchAll();
$locs = $pdo->query("SELECT id, name FROM locations  ORDER BY name")->fetchAll();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Products</h4>
  <a class="btn btn-primary" href="/profitradar/public/product_edit.php">Add Product</a>
</div>

<form class="row g-2 mb-3">
  <div class="col-md-4">
    <input class="form-control" name="q" value="<?= h($q) ?>"
           placeholder="Search code, name, or price">
  </div>

  <div class="col-md-3">
    <select class="form-select" name="category_id">
      <option value="">All Categories</option>
      <?php foreach($cats as $c): ?>
        <option value="<?= (int)$c['id'] ?>" <?= ((string)$c['id'] === (string)$catId ? 'selected' : '') ?>>
          <?= h($c['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-3">
    <select class="form-select" name="supplier_id">
      <option value="">All Suppliers</option>
      <?php foreach($sups as $s): ?>
        <option value="<?= (int)$s['id'] ?>" <?= ((string)$s['id'] === (string)$supId ? 'selected' : '') ?>>
          <?= h($s['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-md-2">
    <select class="form-select" name="location_id">
      <option value="">All Locations</option>
      <?php foreach($locs as $l): ?>
        <option value="<?= (int)$l['id'] ?>" <?= ((string)$l['id'] === (string)$locId ? 'selected' : '') ?>>
          <?= h($l['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="col-12 col-md-2 mt-2">
    <button class="btn btn-outline-secondary w-100">Search</button>
  </div>
</form>

<table class="table table-striped table-sm align-middle">
  <thead>
    <tr>
      <th>Code</th>
      <th>Name</th>
      <th>Category</th>
      <th>Supplier</th>
      <th>Location</th>
      <th class="text-end">Price</th>
      <th class="text-center">Stock</th>
      <th>Barcode</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($st as $p): $low = is_low_stock($pdo,$p); ?>
    <tr>
      <td><?= h($p['code']) ?></td>
      <td><?= h($p['name']) ?><?= $low? ' <span class="badge bg-danger ms-1">Low</span>':'' ?></td>
      <td><?= h($p['category_name'] ?: $p['category']) ?></td>  <!-- prefer linked, fallback legacy -->
      <td><?= h($p['supplier_name'] ?? '') ?></td>
      <td><?= h($p['location_name'] ?: $p['location']) ?></td>  <!-- prefer linked, fallback legacy -->
      <td class="text-end">₱<?= number_format((float)$p['sell_price'],2) ?></td>

      <!-- Stock cell: formatted with unit (pc or kg/etc) -->
      <td class="text-center">
        <?= fmt_stock($p['stock_qty'], $p['sold_by'] ?? 'each', $p['unit'] ?? '') ?>
      </td>

      <td>
        <?php if(!empty($p['barcode'])): ?>
          <svg class="barcode" jsbarcode-format="code128" jsbarcode-value="<?= h($p['barcode']) ?>" jsbarcode-height="24"></svg>
        <?php endif; ?>
      </td>
      <td class="text-end">
        <a class="btn btn-sm btn-outline-secondary" href="/profitradar/public/product_edit.php?id=<?= (int)$p['id'] ?>">Edit</a>
        <?php if(has_role('admin')): ?>
          <a class="btn btn-sm btn-outline-danger" href="/profitradar/public/product_delete.php?id=<?= (int)$p['id'] ?>" onclick="return confirm('Archive this product?');">Archive</a>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<script>
document.addEventListener('DOMContentLoaded', ()=>{
  if (window.JsBarcode) {
    document.querySelectorAll('svg.barcode').forEach(el=>{
      JsBarcode(el, el.getAttribute('jsbarcode-value'), {height:24, displayValue:false});
    });
  }
});
</script>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
