<?php
require_once __DIR__ . '/../includes/config.php';
header('Location: ' . app_url('login.php'));
