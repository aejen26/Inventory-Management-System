<?php
require_once __DIR__ . '/../../includes/header.php';
require_role(['admin','staff','auditor']);
$pdo = getDB();

/* ----------------- Very simple controls ----------------- */
$q        = trim($_GET['q'] ?? '');
$lookback = 14;                 // fixed: 14-day history
$today    = date('Y-m-d');
$from     = date('Y-m-d', strtotime("-$lookback days", strtotime($today)));

/* ----------------- Products (active) ----------------- */
$sqlP = "SELECT p.id, p.code, p.name, p.stock_qty
         FROM products p
         WHERE p.is_active = 1";
$paramsP = [];
if ($q !== '') {
  $sqlP .= " AND (p.code LIKE ? OR p.name LIKE ?)";
  $like = '%'.$q.'%';
  $paramsP[] = $like; $paramsP[] = $like;
}
$sqlP .= " ORDER BY p.name ASC";
$stP = $pdo->prepare($sqlP);
$stP->execute($paramsP);
$products = $stP->fetchAll(PDO::FETCH_UNIQUE|PDO::FETCH_ASSOC); // keyed by id

$pids = array_keys($products);

/* ----------------- Last 14 days sales per product ----------------- */
$sales = []; // pid => ['qty'=>int, 'last'=>'Y-m-d']
if ($pids) {
  $in = implode(',', array_fill(0, count($pids), '?'));
  $sqlS = "
    SELECT ti.product_id AS pid,
           SUM(ti.qty)   AS qty_sum,
           MAX(t.date)   AS last_date
    FROM transaction_items ti
    JOIN transactions t ON t.id = ti.transaction_id
    WHERE t.type = 'sale'
      AND t.date BETWEEN ? AND ?
      AND ti.product_id IN ($in)
    GROUP BY ti.product_id
  ";
  $stS = $pdo->prepare($sqlS);
  $stS->execute(array_merge([$from, $today], $pids));
  foreach ($stS as $r) {
    $sales[(int)$r['pid']] = [
      'qty'  => (int)$r['qty_sum'],
      'last' => $r['last_date']
    ];
  }
}

/* ----------------- Build simple rows ----------------- */
$rows = [];
$totalForecast = 0; $totalReorder = 0; $count = 0;

foreach ($products as $pid => $p) {
  $stock   = (int)$p['stock_qty'];
  $sold14  = $sales[$pid]['qty'] ?? 0;
  $last    = $sales[$pid]['last'] ?? null;

  $avgPerDay   = $sold14 > 0 ? ($sold14 / $lookback) : 0.0;
  $forecast7   = $avgPerDay * 7.0;
  $reorderNeed = max(0, (int)ceil($forecast7 - $stock));

  $rows[] = [
    'code'        => $p['code'],
    'name'        => $p['name'],
    'stock'       => $stock,
    'avg_per_day' => $avgPerDay,
    'forecast7'   => $forecast7,
    'reorder'     => $reorderNeed,
    'last_sale'   => $last
  ];

  $totalForecast += $forecast7;
  $totalReorder  += $reorderNeed;
  $count++;
}

/* Sort: highest reorder need first, then by forecast */
usort($rows, function($a,$b){
  if ($a['reorder'] !== $b['reorder']) return $b['reorder'] <=> $a['reorder'];
  return $b['forecast7'] <=> $a['forecast7'];
});
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">7-Day Forecast</h4>
  <div class="text-end small">
    <div><strong>Look-back:</strong> 14 days</div>
  </div>
</div>

<form class="row g-2 mb-3">
  <div class="col-md-5">
    <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Search code or name">
  </div>
  <div class="col-md-2">
    <button class="btn btn-outline-secondary w-100">Search</button>
  </div>
</form>

<!-- Tiny summary -->
<div class="row g-3 mb-3">
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="text-muted small">Products</div>
      <div class="fs-5"><?= (int)$count ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="text-muted small">Forecast (next 7d)</div>
      <div class="fs-5"><?= number_format($totalForecast, 0) ?> units</div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="p-3 bg-light border rounded">
      <div class="text-muted small">Recommended to Order</div>
      <div class="fs-5"><?= number_format($totalReorder, 0) ?> units</div>
    </div>
  </div>
</div>

<table class="table table-striped table-sm align-middle">
  <thead>
    <tr>
      <th style="width:16%">Code</th>
      <th>Product</th>
      <th class="text-center" style="width:10%">Stock</th>
      <th class="text-end" style="width:14%">Avg / Day</th>
      <th class="text-end" style="width:14%">Forecast 7d</th>
      <th class="text-end" style="width:14%">Reorder</th>
      <th style="width:16%">Last Sale</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!$rows): ?>
      <tr><td colspan="7" class="text-muted">No matching products.</td></tr>
    <?php else: ?>
      <?php foreach ($rows as $r):
        $warn = ($r['reorder'] > 0); // needs reorder
      ?>
        <tr<?= $warn ? ' class="table-warning"' : '' ?>>
          <td><?= h($r['code']) ?></td>
          <td><?= h($r['name']) ?></td>
          <td class="text-center"><?= (int)$r['stock'] ?></td>
          <td class="text-end"><?= number_format($r['avg_per_day'], 2) ?></td>
          <td class="text-end"><?= number_format($r['forecast7'], 0) ?></td>
          <td class="text-end fw-bold"><?= (int)$r['reorder'] ?></td>
          <td><?= $r['last_sale'] ? h($r['last_sale']) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
</table>

<!--<p class="text-muted small mb-0">
  <strong>How it’s calculated:</strong>
  We total units sold in the last 14 days, divide by 14 to get Avg/Day, multiply by 7 to forecast the next week.
  If current stock is less than that forecast, we recommend ordering the difference.
</p>-->

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
