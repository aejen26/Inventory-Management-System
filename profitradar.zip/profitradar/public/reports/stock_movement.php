<?php
require_once __DIR__ . '/../../includes/header.php';
require_role(['admin','staff','auditor']);
$pdo = getDB();

/* ---------- Filters ---------- */
$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');
$q    = trim($_GET['q'] ?? '');
$loc  = trim($_GET['location'] ?? '');   // optional product location filter

/* Build WHERE fragments used by subqueries */
$whereProd = "p.is_active = 1";
$paramsOpen = [];
$paramsPeriod = [];

/* Product text search (code/name) */
if ($q !== '') {
  $whereProd .= " AND (p.code LIKE ? OR p.name LIKE ?)";
  $like = '%'.$q.'%';
  $paramsOpen[] = $like; $paramsOpen[] = $like;
  $paramsPeriod[] = $like; $paramsPeriod[] = $like;
}

/* Product location filter */
if ($loc !== '') {
  $whereProd .= " AND p.location = ?";
  $paramsOpen[] = $loc;
  $paramsPeriod[] = $loc;
}

/* ---------- Opening balances (before $from) ---------- */
$sqlOpening = "
  SELECT
    p.id,
    COALESCE(SUM(
      CASE t.type
        WHEN 'purchase' THEN ti.qty
        WHEN 'sale'     THEN -ti.qty
        ELSE 0
      END
    ),0) AS opening_qty
  FROM products p
  LEFT JOIN transaction_items ti ON ti.product_id = p.id
  LEFT JOIN transactions t ON t.id = ti.transaction_id
        AND t.type IN ('purchase','sale')
        AND t.date < ?
  WHERE $whereProd
  GROUP BY p.id
";
$stOpen = $pdo->prepare($sqlOpening);
$stOpen->execute(array_merge([$from], $paramsOpen));
$openingById = [];
foreach ($stOpen as $r) $openingById[(int)$r['id']] = (int)$r['opening_qty'];

/* ---------- Period movements (between $from and $to) ---------- */
$sqlPeriod = "
  SELECT
    p.id, p.code, p.name, p.location,
    SUM(CASE WHEN t.type='purchase' THEN ti.qty ELSE 0 END)               AS in_qty,
    SUM(CASE WHEN t.type='purchase' THEN ti.qty*ti.unit_price ELSE 0 END) AS in_value,
    SUM(CASE WHEN t.type='sale' THEN ti.qty ELSE 0 END)                   AS out_qty,
    SUM(CASE WHEN t.type='sale' THEN ti.qty*ti.unit_price ELSE 0 END)     AS out_value
  FROM products p
  LEFT JOIN transaction_items ti ON ti.product_id = p.id
  LEFT JOIN transactions t ON t.id = ti.transaction_id
        AND t.type IN ('purchase','sale')
        AND t.date BETWEEN ? AND ?
  WHERE $whereProd
  GROUP BY p.id, p.code, p.name, p.location
  ORDER BY p.name
";
$stPeriod = $pdo->prepare($sqlPeriod);
$stPeriod->execute(array_merge([$from, $to], $paramsPeriod));
$rows = $stPeriod->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Detail lines per product (for drilldown) ---------- */
$productIds = array_column($rows, 'id');
$detailsByProduct = [];
if ($productIds) {
  $inClause = implode(',', array_fill(0, count($productIds), '?'));
  $sqlLines = "
    SELECT
      p.id AS product_id,
      t.id AS tx_id, t.type, t.ref_no, t.date, t.created_at,
      ti.qty, ti.unit_price,
      -- net of line-level discount (if present)
      GREATEST(
        0,
        (ti.qty*ti.unit_price) -
        CASE
          WHEN ti.discount_type='percent' AND ti.discount_value IS NOT NULL
            THEN (ti.qty*ti.unit_price)*(ti.discount_value/100)
          WHEN ti.discount_type='amount'  AND ti.discount_value IS NOT NULL
            THEN ti.discount_value
          ELSE 0
        END
      ) AS line_total
    FROM transactions t
    JOIN transaction_items ti ON ti.transaction_id=t.id
    JOIN products p ON p.id = ti.product_id
    WHERE t.type IN ('purchase','sale')
      AND t.date BETWEEN ? AND ?
      AND p.id IN ($inClause)
    ORDER BY p.name, t.date, t.id, ti.id
  ";
  $stLines = $pdo->prepare($sqlLines);
  $stLines->execute(array_merge([$from, $to], $productIds));
  foreach ($stLines as $r) {
    $detailsByProduct[(int)$r['product_id']][] = $r;
  }
}

/* ---------- Totals for ribbon ---------- */
$totalInQty=0; $totalOutQty=0; $totalInVal=0.0; $totalOutVal=0.0;
foreach ($rows as &$r) {
  $pid = (int)$r['id'];
  $open = $openingById[$pid] ?? 0;
  $inQ  = (int)$r['in_qty'];
  $outQ = (int)$r['out_qty'];
  $r['opening_qty'] = $open;
  $r['closing_qty'] = $open + $inQ - $outQ;

  $totalInQty  += $inQ;
  $totalOutQty += $outQ;
  $totalInVal  += (float)$r['in_value'];
  $totalOutVal += (float)$r['out_value'];
}
unset($r);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Stock Movement</h4>
  <div class="text-end small">
    <div><span class="badge bg-success">IN</span>
      <span class="ms-1"><?= (int)$totalInQty ?> qty • ₱<?= number_format($totalInVal,2) ?></span>
    </div>
    <div class="mt-1"><span class="badge bg-danger">OUT</span>
      <span class="ms-1"><?= (int)$totalOutQty ?> qty • ₱<?= number_format($totalOutVal,2) ?></span>
    </div>
    <div class="mt-1 text-muted">Net qty change:
      <strong><?= ($totalInQty-$totalOutQty>=0?'+':'').(int)($totalInQty-$totalOutQty) ?></strong>
    </div>
  </div>
</div>

<form class="row g-2 mb-3">
  <div class="col-md-2">
    <label class="form-label">From</label>
    <input type="date" class="form-control" name="from" value="<?= h($from) ?>">
  </div>
  <div class="col-md-2">
    <label class="form-label">To</label>
    <input type="date" class="form-control" name="to" value="<?= h($to) ?>">
  </div>
  <div class="col-md-4">
    <label class="form-label">Product</label>
    <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Search code or name">
  </div>
  <!--<div class="col-md-3">
    <label class="form-label">Location</label>
    <input class="form-control" name="location" value="<?= h($loc) ?>" placeholder="Optional">
  </div>-->
  <div class="col-md-1 align-self-end">
    <button class="btn btn-outline-secondary w-100">Filter</button>
  </div>
</form>

<table class="table table-striped table-sm align-middle">
  <thead>
    <tr>
      <th style="width:16%">Code</th>
      <th>Product</th>
      <!--<th style="width:12%">Location</th>-->
      <!--<th class="text-end" style="width:8%">Opening</th>-->
      <th class="text-end" style="width:8%">IN</th>
      <th class="text-end" style="width:10%">IN Value</th>
      <th class="text-end" style="width:8%">OUT</th>
      <th class="text-end" style="width:10%">OUT Value</th>
      <th class="text-end" style="width:8%">Closing</th>
      <th style="width:44px;"></th>
    </tr>
  </thead>
  <tbody>
    <?php if (!$rows): ?>
      <tr><td colspan="10" class="text-muted">No movement found for this filter.</td></tr>
    <?php else: ?>
      <?php foreach ($rows as $r):
        $pid = (int)$r['id'];
        $lines = $detailsByProduct[$pid] ?? [];
      ?>
        <tr class="table-secondary">
          <td><?= h($r['code']) ?></td>
          <td><?= h($r['name']) ?></td>
          <!--<td><?= h($r['location']) ?></td>-->
          <!--<td class="text-end"><?= (int)$r['opening_qty'] ?></td>-->
          <td class="text-end"><?= (int)$r['in_qty'] ?></td>
          <td class="text-end">₱<?= number_format((float)$r['in_value'],2) ?></td>
          <td class="text-end"><?= (int)$r['out_qty'] ?></td>
          <td class="text-end">₱<?= number_format((float)$r['out_value'],2) ?></td>
          <td class="text-end"><?= (int)$r['closing_qty'] ?></td>
          <td class="text-end">
            <?php if ($lines): ?>
              <button class="btn btn-sm btn-outline-secondary"
                      data-bs-toggle="collapse" data-bs-target="#p<?= $pid ?>">View</button>
            <?php endif; ?>
          </td>
        </tr>
        <?php if ($lines): ?>
          <tr id="p<?= $pid ?>" class="collapse">
            <td colspan="10" class="p-0">
              <table class="table table-sm mb-0">
                <thead>
                  <tr>
                    <th style="width:14%">Date/Time</th>
                    <th style="width:12%">Type</th>
                    <th style="width:18%">Ref</th>
                    <th class="text-end" style="width:10%">Qty</th>
                    <th class="text-end" style="width:12%">Unit</th>
                    <th class="text-end" style="width:12%">Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($lines as $ln):
                    $dtRaw  = $ln['created_at'] ?: $ln['date'];
                    $dtDisp = $dtRaw ? date('Y-m-d H:i', strtotime($dtRaw)) : '';
                  ?>
                    <tr>
                      <td><?= h($dtDisp) ?></td>
                      <td><?= h(ucfirst($ln['type'])) ?></td>
                      <td><?= h($ln['ref_no']) ?></td>
                      <td class="text-end"><?= (int)$ln['qty'] ?></td>
                      <td class="text-end">₱<?= number_format((float)$ln['unit_price'],2) ?></td>
                      <td class="text-end">₱<?= number_format((float)$ln['line_total'],2) ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </td>
          </tr>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php endif; ?>
  </tbody>
</table>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
