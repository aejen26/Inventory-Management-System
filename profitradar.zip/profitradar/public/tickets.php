<?php
// public/tickets.php
require_once __DIR__ . '/../includes/header.php';
require_role(['admin','staff']); // restrict who can view/manage tickets

// ensure session
if (session_status() === PHP_SESSION_NONE) session_start();

// fetch tickets from session
$ticketsRaw = $_SESSION['tickets'] ?? [];
$tickets = [];

// normalize (support assoc keyed or indexed)
if ($ticketsRaw) {
  $isAssoc = array_keys($ticketsRaw) !== range(0, count($ticketsRaw) - 1);
  if ($isAssoc) {
    foreach ($ticketsRaw as $k => $t) {
      if (is_array($t)) $tickets[] = $t;
    }
  } else {
    foreach ($ticketsRaw as $t) {
      if (is_array($t)) $tickets[] = $t;
    }
  }
}

// helper to build ticket id (if none)
function ticket_id_from($t) {
  if (!empty($t['id'])) return (string)$t['id'];
  if (!empty($t['key'])) return (string)$t['key'];
  return substr(md5(json_encode($t)), 0, 10);
}

// handle delete actions POST (safer)
$flash = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // simple CSRF guard: use the existing token helper
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
    $flash = ['type'=>'danger','msg'=>'Invalid CSRF token'];
  } else {
    if (isset($_POST['action']) && $_POST['action'] === 'delete_one' && !empty($_POST['ticket_id'])) {
      $tid = (string)$_POST['ticket_id'];
      // remove by id or by key
      foreach ($_SESSION['tickets'] ?? [] as $k => $t) {
        $id = ticket_id_from($t);
        if ($id === $tid) {
          unset($_SESSION['tickets'][$k]);
        }
      }
      $flash = ['type'=>'success','msg'=>"Ticket $tid deleted."];
      // reload normalized array
      $ticketsRaw = $_SESSION['tickets'] ?? [];
      $tickets = is_array($ticketsRaw) ? array_values($ticketsRaw) : [];
    } elseif (isset($_POST['action']) && $_POST['action'] === 'delete_all') {
      unset($_SESSION['tickets']);
      $tickets = [];
      $flash = ['type'=>'success','msg'=>'All tickets deleted.'];
    }
  }
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Saved Tickets</h4>
  <div>
    <a class="btn btn-outline-secondary" href="/profitradar/public/sale_add.php">Open POS</a>
    <form method="post" style="display:inline-block" onsubmit="return confirm('Delete ALL tickets?');">
      <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="delete_all">
      <button class="btn btn-danger">Delete All</button>
    </form>
  </div>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= h($flash['type']) ?>"><?= h($flash['msg']) ?></div>
<?php endif; ?>

<?php if (empty($tickets)): ?>
  <div class="alert alert-info">No saved tickets.</div>
<?php else: ?>

  <div class="table-responsive mb-3">
    <table class="table table-sm">
      <thead>
        <tr>
          <th>Ticket ID</th>
          <th>Created</th>
          <th># Items</th>
          <th>Preview</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($tickets as $t):
          $tid = ticket_id_from($t);
          $created = $t['created_at'] ?? ($t['created'] ?? null);
          $items = $t['items'] ?? ($t['lines'] ?? []);
          $count = is_array($items) ? count($items) : 0;
        ?>
        <tr>
          <td class="text-monospace"><?= h($tid) ?></td>
          <td><?= h($created ? date('Y-m-d H:i', strtotime($created)) : '—') ?></td>
          <td><?= (int)$count ?></td>
          <td>
            <button class="btn btn-sm btn-outline-primary btn-preview" data-id="<?= h($tid) ?>" <?= $count ? '' : 'disabled' ?>>
              Preview
            </button>
          </td>
          <td class="text-end">
            <a class="btn btn-sm btn-primary" href="/profitradar/public/sale_add.php?load_ticket=<?= urlencode($tid) ?>">Load</a>

            <form method="post" style="display:inline-block" onsubmit="return confirm('Delete ticket <?= h($tid) ?>?');">
              <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete_one">
              <input type="hidden" name="ticket_id" value="<?= h($tid) ?>">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

<?php endif; ?>

<!-- Ticket Preview Modal -->
<div class="modal fade" id="ticketPreviewModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Ticket Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="ticketPreviewHeader" class="mb-3 small text-muted"></div>

        <div class="table-responsive">
          <table class="table table-sm">
            <thead>
              <tr><th>Code</th><th>Item</th><th class="text-end">Qty</th><th class="text-end">Unit</th><th class="text-end">Line</th></tr>
            </thead>
            <tbody id="ticketPreviewLines"></tbody>
            <tfoot>
              <tr>
                <th colspan="4" class="text-end">Total</th>
                <th id="ticketPreviewTotal" class="text-end">₱0.00</th>
              </tr>
            </tfoot>
          </table>
        </div>

      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('.btn-preview');
  if (!btn) return;
  const id = btn.dataset.id;
  if (!id) { alert('Missing ticket id'); return; }

  const fd = new FormData();
  fd.append('ticket_id', id);
  fd.append('csrf', '<?= h(csrf_token()) ?>');

  try {
    const res = await fetch('<?= APP_BASE ?>/public/api/tickets_view.php', {
      method: 'POST',
      body: fd,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    });
    const j = await res.json();
    if (!j.ok) {
      return alert(j.error || 'Failed to load ticket');
    }

    const hdr = j.ticket || {};
    const lines = j.lines || [];
    const total = j.total || 0;

    const headerEl = document.getElementById('ticketPreviewHeader');
    headerEl.innerHTML = `
      <div><strong>Ref:</strong> ${hdr.ref ?? hdr.id ?? ''}</div>
      <div><small>${hdr.created_at ?? ''} — ${hdr.customer ?? '— walk-in —'}</small></div>
      <div><small>By: ${hdr.user ?? ''}</small></div>
    `;

    const bodyEl = document.getElementById('ticketPreviewLines');
    bodyEl.innerHTML = '';
// inside your tickets.php script (replace the existing loop that builds each <tr> content)
for (const L of lines) {
  const qty = Number(L.qty);
  const unit = Number(L.unit_price || 0).toFixed(2);
  const lineTotal = Number(L.line_total || 0).toFixed(2);

  // fallback text
  const codeText = L.code || L.sku || '—';
  const nameText = L.name || 'Unnamed item';

  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td>${escapeHtml(codeText)}</td>
    <td>${escapeHtml(nameText)}</td>
    <td class="text-end">${(qty % 1 === 0) ? qty.toFixed(0) : qty}</td>
    <td class="text-end">₱${unit}</td>
    <td class="text-end">₱${lineTotal}</td>
  `;
  bodyEl.appendChild(tr);
}

// tiny helper to avoid XSS when building strings
function escapeHtml(s){
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]; });
}


    document.getElementById('ticketPreviewTotal').textContent = '₱' + Number(total).toFixed(2);

    // show modal (Bootstrap 5)
    const modalEl = document.getElementById('ticketPreviewModal');
    const modal = new bootstrap.Modal(modalEl);
    modal.show();

  } catch (err) {
    console.error(err);
    alert('Failed to fetch ticket — see console');
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
