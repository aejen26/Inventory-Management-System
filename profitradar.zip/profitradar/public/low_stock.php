<?php
require_once __DIR__.'/../includes/header.php';
require_role(['admin','staff']);
$pdo=getDB(); check_csrf();

// Update per-product thresholds
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['th'])){
  foreach($_POST['th'] as $pid=>$val){
    $pid=(int)$pid; $v=trim($val);
    if($v==='') $pdo->prepare('UPDATE products SET low_stock_threshold=NULL WHERE id=?')->execute([$pid]);
    else $pdo->prepare('UPDATE products SET low_stock_threshold=? WHERE id=?')->execute([(int)$v,$pid]);
  }
}

$global = (int)get_setting($pdo,'low_stock_default',5);
$products=$pdo->prepare('SELECT id,code,name,stock_qty,low_stock_threshold FROM products WHERE is_active=1 ORDER BY name');
$products->execute();
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Low Stock Alerts</h4>
</div>
<div class="alert alert-secondary">Global default threshold: <strong><?= (int)$global ?></strong>. Override per item below. Leave blank to use global.</div>
<form method="post">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <table class="table table-sm align-middle">
    <thead><tr><th>Code</th><th>Name</th><th class="text-center">Stock</th><th style="width:180px">Threshold</th></tr></thead>
    <tbody>
      <?php foreach($products as $p): ?>
      <tr>
        <td><?= h($p['code']) ?></td>
        <td><?= h($p['name']) ?></td>
        <td class="text-center"><?= (int)$p['stock_qty'] ?></td>
        <td><input class="form-control" type="number" name="th[<?= (int)$p['id'] ?>]" value="<?= h($p['low_stock_threshold']) ?>" placeholder="(<?= (int)$global ?>)"></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <div class="text-end"><button class="btn btn-primary">Save Thresholds</button></div>
</form>
<?php require_once __DIR__.'/../includes/footer.php'; ?>