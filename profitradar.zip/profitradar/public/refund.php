<?php
// public/refund.php
require_once __DIR__ . '/../includes/header.php';
require_login();

// force timezone to local (Philippines)
date_default_timezone_set('Asia/Manila');

$pdo = getDB();
if (function_exists('check_csrf')) check_csrf(); // validate POST csrf if available

// sale_id must be provided
$sale_id = isset($_GET['sale_id']) ? (int)$_GET['sale_id'] : 0;
if ($sale_id <= 0) {
    echo '<div class="container"><div class="alert alert-danger">Missing sale_id.</div></div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

/* ---------- load sale header ---------- */
$st = $pdo->prepare("SELECT t.*, u.name AS user_name, COALESCE(c.name,'') AS customer_name
                     FROM transactions t
                     JOIN users u ON u.id = t.user_id
                     LEFT JOIN customers c ON c.id = t.customer_id
                     WHERE t.id = ? AND t.type = 'sale' LIMIT 1");
$st->execute([$sale_id]);
$sale = $st->fetch(PDO::FETCH_ASSOC);
if (!$sale) {
    echo '<div class="container"><div class="alert alert-danger">Sale not found or not a sale.</div></div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

/* ---------- load sale items ---------- */
$li = $pdo->prepare("SELECT ti.id, ti.product_id, ti.qty, ti.unit_price, p.code, p.name
                     FROM transaction_items ti
                     JOIN products p ON p.id = ti.product_id
                     WHERE ti.transaction_id = ?
                     ORDER BY ti.id");
$li->execute([$sale_id]);
$items = $li->fetchAll(PDO::FETCH_ASSOC);
if (!$items) $items = [];

/* ---------- compute already refunded quantities from audit_log ---------- */
/*
  Assumes your refund flow inserts an audit_log row with new_data JSON containing:
    { "type":"refund", "sale_id": <sale_id>, "refund_tx": <txid>, "items":[{ "line_id":..., "product_id":..., "qty":... }, ...] }
*/
$alreadyRefunded = []; // keyed by original transaction_items.id (line id) or 'p:<product_id>'
try {
    $ast = $pdo->prepare("SELECT new_data FROM audit_log WHERE new_data LIKE ? OR description LIKE ? ORDER BY created_at DESC");
    $likePattern = '%"sale_id":' . $sale_id . '%';
    $ast->execute([$likePattern, '%sale_id='.$sale_id.'%']);
    while ($row = $ast->fetch(PDO::FETCH_ASSOC)) {
        if (empty($row['new_data'])) continue;
        $parsed = @json_decode($row['new_data'], true);
        if (!is_array($parsed)) continue;
        if (!empty($parsed['items']) && is_array($parsed['items'])) {
            foreach ($parsed['items'] as $it) {
                $lineId = isset($it['line_id']) ? (int)$it['line_id'] : null;
                $prodId = isset($it['product_id']) ? (int)$it['product_id'] : null;
                $qty = isset($it['qty']) ? (float)$it['qty'] : 0.0;
                if ($lineId) {
                    if (!isset($alreadyRefunded[$lineId])) $alreadyRefunded[$lineId] = 0.0;
                    $alreadyRefunded[$lineId] += $qty;
                } elseif ($prodId) {
                    $k = 'p:' . $prodId;
                    if (!isset($alreadyRefunded[$k])) $alreadyRefunded[$k] = 0.0;
                    $alreadyRefunded[$k] += $qty;
                }
            }
        }
    }
} catch (Throwable $e) {
    // non-fatal: proceed without audit data if read fails
    $alreadyRefunded = [];
}

/* ---------- POST: build refund transaction (server-side checks against already refunded) ---------- */
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted = $_POST;
    $refundQtys = $posted['refund_qty'] ?? [];
    $notes = trim($posted['notes'] ?? '');

    // collect items to refund (enforce remaining qty <= original - already refunded)
    $toRefund = [];
    foreach ($items as $it) {
        $lineId = (int)$it['id'];
        $origQty = (float)$it['qty'];
        $key = (string)$lineId;
        if (!isset($refundQtys[$key])) continue;
        $rq = $refundQtys[$key];
        if ($rq === '' || !is_numeric($rq)) continue;
        $rqn = (float)$rq;
        if ($rqn <= 0) continue;

        $already = isset($alreadyRefunded[$lineId]) ? (float)$alreadyRefunded[$lineId] : 0.0;
        if ($already == 0.0) {
            $k = 'p:' . ((int)$it['product_id']);
            if (isset($alreadyRefunded[$k])) $already = (float)$alreadyRefunded[$k];
        }
        $remaining = max(0, $origQty - $already);

        if ($rqn > $remaining) {
            $error = "Requested refund quantity for line '{$it['name']}' exceeds remaining refundable quantity ({$remaining}).";
            $rqn = $remaining;
        }

        if ($rqn <= 0) continue;

        $toRefund[] = [
            'line_id' => $lineId,
            'product_id' => (int)$it['product_id'],
            'qty' => $rqn,
            'unit_price' => (float)$it['unit_price'],
            'code' => $it['code'] ?? '',
            'name' => $it['name'] ?? ''
        ];
    }

    if (empty($toRefund) && $error === null) {
        $error = 'No item quantities selected for refund.';
    }

    if ($error === null) {
        try {
            $pdo->beginTransaction();

            // race-check: recompute latest already refunded just before writing
            $latestAlready = [];
            $ast2 = $pdo->prepare("SELECT new_data FROM audit_log WHERE new_data LIKE ? OR description LIKE ? ORDER BY created_at DESC");
            $likePattern2 = '%"sale_id":' . $sale_id . '%';
            $ast2->execute([$likePattern2, '%sale_id='.$sale_id.'%']);
            while ($row2 = $ast2->fetch(PDO::FETCH_ASSOC)) {
                if (empty($row2['new_data'])) continue;
                $parsed2 = @json_decode($row2['new_data'], true);
                if (!is_array($parsed2)) continue;
                if (!empty($parsed2['items']) && is_array($parsed2['items'])) {
                    foreach ($parsed2['items'] as $it2) {
                        $l2 = isset($it2['line_id']) ? (int)$it2['line_id'] : null;
                        $p2 = isset($it2['product_id']) ? (int)$it2['product_id'] : null;
                        $q2 = isset($it2['qty']) ? (float)$it2['qty'] : 0.0;
                        if ($l2) { if (!isset($latestAlready[$l2])) $latestAlready[$l2]=0.0; $latestAlready[$l2]+=$q2; }
                        elseif ($p2) { $k='p:'.$p2; if (!isset($latestAlready[$k])) $latestAlready[$k]=0.0; $latestAlready[$k]+=$q2; }
                    }
                }
            }

            // enforce again
            foreach ($toRefund as $r) {
                $line = (int)$r['line_id'];
                $orig = 0.0;
                foreach ($items as $it) { if ((int)$it['id'] === $line) { $orig = (float)$it['qty']; break; } }
                $alreadyNow = isset($latestAlready[$line]) ? (float)$latestAlready[$line] : 0.0;
                $remainingNow = max(0, $orig - $alreadyNow);
                if ($r['qty'] > $remainingNow) {
                    throw new Exception("Refund quantity for '{$r['name']}' exceeds remaining refundable quantity ({$remainingNow}). Aborting.");
                }
            }

            // === compute timestamps using a fixed timezone ===
// create timezone-aware timestamps (use Asia/Manila or change to your timezone)
$tz = new DateTimeZone('Asia/Manila');
$now = (new DateTime('now', $tz))->format('Y-m-d H:i:s');

// prefer sale date if present, otherwise use today's date (in same timezone)
if (!empty($sale['date']) && preg_match('/^\d{4}-\d{2}-\d{2}/', $sale['date'])) {
    $refundDate = (new DateTime($sale['date'], $tz))->format('Y-m-d');
} elseif (!empty($sale['created_at'])) {
    $refundDate = (new DateTime($sale['created_at'], $tz))->format('Y-m-d');
} else {
    $refundDate = (new DateTime('now', $tz))->format('Y-m-d');
}

// prepare tx insert (store both date and created_at)
$refno = 'R_' . (new DateTime('now', $tz))->format('Ymd') . '_' . mt_rand(1000, 9999);
$user_id = (int)($_SESSION['user']['id'] ?? 0);

$netValue = 0.0;
foreach ($toRefund as $r) $netValue += ($r['qty'] * $r['unit_price']);
$netValue = -abs($netValue);

$insTx = $pdo->prepare("INSERT INTO transactions (type, ref_no, date, created_at, user_id, customer_id, notes, net_value)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$custId = $sale['customer_id'] ?? null;
$insTx->execute(['refund', $refno, $refundDate, $now, $user_id, $custId, $notes, $netValue]);
$refundTxId = (int)$pdo->lastInsertId();

$insItem = $pdo->prepare("INSERT INTO transaction_items
    (transaction_id, product_id, qty, unit_price, discount_type, discount_value)
    VALUES (?, ?, ?, ?, NULL, NULL)");
$updProduct = $pdo->prepare("UPDATE products
    SET stock_qty = COALESCE(stock_qty,0) + ?, retail_stock = COALESCE(retail_stock,0) + ?, wholesale_stock = COALESCE(wholesale_stock,0) + ?
    WHERE id = ?");

foreach ($toRefund as $r) {
    $insItem->execute([$refundTxId, $r['product_id'], $r['qty'], $r['unit_price']]);
    $updProduct->execute([$r['qty'], $r['qty'], $r['qty'], $r['product_id']]);
}

$auditStmt = $pdo->prepare("INSERT INTO audit_log (user_id, description, new_data, created_at) VALUES (?, ?, ?, ?)");
$desc = "Refund created for sale_id={$sale_id}, refund_tx={$refundTxId}";
$newdata = json_encode([
    'type'=>'refund',
    'sale_id'=>$sale_id,
    'sale_date'=>($sale['date'] ?? $sale['created_at'] ?? null),
    'refund_tx'=>$refundTxId,
    'refund_date'=>$refundDate,
    'items'=>$toRefund
]);
$auditStmt->execute([$user_id, $desc, $newdata, $now]);

$pdo->commit();

// client redirect: point to transactions page on the refund date (so it shows in that day's bucket)
$locFrom = urlencode(date('Y-m-01', strtotime($refundDate)));
$locTo   = urlencode(date('Y-m-d', strtotime($refundDate)));
$redirectUrl = "transactions.php?from={$locFrom}&to={$locTo}&type=refund";

// use JS redirect + noscript fallback because headers may already be sent
echo '<script>window.location.href = "' . htmlspecialchars($redirectUrl, ENT_QUOTES) . '";</script>';
echo '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($redirectUrl, ENT_QUOTES) . '" /></noscript>';
exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = 'Server error: ' . $e->getMessage();
        }
    }
}

/* ---------- Display UI ---------- */
?>
<div class="container container-wide">
  <h4>Refund Sale: <?= h($sale['ref_no'] ?? ('S_'.$sale_id)) ?></h4>
  <div class="card mb-3">
    <div class="card-body">
      <div><strong>Date:</strong> <?= h($sale['date'] ?? $sale['created_at']) ?></div>
      <div><strong>By:</strong> <?= h($sale['user_name'] ?? '—') ?></div>
      <div><strong>Customer:</strong> <?= h($sale['customer_name'] ?: '— walk-in —') ?></div>
      <div class="mt-2 text-muted small">Select quantity per line to refund. Partial refunds allowed. Previously refunded quantities are taken into account.</div>
    </div>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="post" id="refundForm">
    <?php if (function_exists('csrf_token')): ?>
      <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
    <?php endif; ?>

    <table class="table table-sm">
      <thead>
        <tr>
          <th>Code</th>
          <th>Item</th>
          <th class="text-end">Original Qty</th>
          <th class="text-end">Already Refunded</th>
          <th class="text-end">Remaining</th>
          <th class="text-end">Unit Price</th>
          <th class="text-end">Refund Qty</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $it):
            $lineId = (int)$it['id'];
            $orig = (float)$it['qty'];
            $unit = (float)$it['unit_price'];
            $already = isset($alreadyRefunded[$lineId]) ? (float)$alreadyRefunded[$lineId] : 0.0;
            if ($already == 0.0) {
                $k = 'p:'.((int)$it['product_id']);
                if (isset($alreadyRefunded[$k])) $already = (float)$alreadyRefunded[$k];
            }
            $remaining = max(0, $orig - $already);
        ?>
          <tr>
            <td><?= h($it['code']) ?></td>
            <td><?= h($it['name']) ?></td>
            <td class="text-end"><?= h($orig) ?></td>
            <td class="text-end"><?= h($already) ?></td>
            <td class="text-end"><?= h($remaining) ?></td>
            <td class="text-end"><?= $unit ? '₱'.number_format($unit,2) : '—' ?></td>
            <td class="text-end" style="width:160px;">
              <?php if ($remaining <= 0): ?>
                <input data-unit="<?= htmlspecialchars($unit) ?>" type="number" step="1" min="0" max="<?= h($remaining) ?>" name="refund_qty[<?= $lineId ?>]" class="form-control form-control-sm refund-qty" placeholder="0" value="0" disabled>
              <?php else: ?>
                <input data-unit="<?= htmlspecialchars($unit) ?>" type="number" step="1" min="0" max="<?= h($remaining) ?>" name="refund_qty[<?= $lineId ?>]" class="form-control form-control-sm refund-qty" placeholder="0" value="0">
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="mb-3 row">
      <div class="col-md-6">
        <label class="form-label">Notes (refund reason)</label>
        <input class="form-control" name="notes" placeholder="Customer changed mind / damaged item / other">
      </div>
      <div class="col-md-6 text-end align-self-end">
        <div class="h5">Refund total: <span id="refundTotal">₱0.00</span></div>
        <div class="text-muted small">Total updates live as you change refundable quantities.</div>
      </div>
    </div>

    <div class="d-flex gap-2">
      <button type="submit" class="btn btn-danger" id="createRefundBtn" disabled>Create Refund</button>
      <a href="transactions.php" class="btn btn-outline-secondary">Cancel</a>
    </div>
  </form>
</div>

<script>
(function(){
  // Find all refund qty inputs
  const qtyInputs = Array.from(document.querySelectorAll('.refund-qty'));
  const totalEl = document.getElementById('refundTotal');
  const createBtn = document.getElementById('createRefundBtn');

  const nf = new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', minimumFractionDigits: 2 });

  function computeTotal() {
    let total = 0.0;
    qtyInputs.forEach(inp => {
      if (inp.disabled) return;
      const v = parseFloat(inp.value || '0');
      if (!isFinite(v) || v <= 0) return;
      const unit = parseFloat(inp.dataset.unit || '0');
      total += v * (isFinite(unit) ? unit : 0);
    });
    // update UI
    totalEl.textContent = nf.format(total);
    // enable create button only if total > 0
    createBtn.disabled = !(total > 0);
  }

  // attach event listeners
  qtyInputs.forEach(inp => {
    // enforce min/max on manual inputs
    inp.addEventListener('input', (e) => {
      const min = parseFloat(inp.getAttribute('min') || '0');
      const max = parseFloat(inp.getAttribute('max') || '0');
      let val = parseFloat(inp.value || '0');
      if (!isFinite(val)) val = 0;
      if (val < min) inp.value = min;
      if (val > max) inp.value = max;
      computeTotal();
    });
    // recompute on change/blur too
    inp.addEventListener('change', computeTotal);
    inp.addEventListener('blur', computeTotal);
  });

  // initial compute in case some inputs are prefilled
  computeTotal();

  // Prevent form submission if create button is disabled (extra safety)
  document.getElementById('refundForm').addEventListener('submit', function(e){
    if (createBtn.disabled) {
      e.preventDefault();
      alert('Please select at least one item quantity to refund.');
    }
  });
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
