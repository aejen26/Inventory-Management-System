<?php
require_once __DIR__ . '/../includes/header.php';
require_role(['admin']);
$pdo = getDB();

$id = (int)($_GET['id'] ?? 0);
if ($id) {
  try {
    // unlink products first so the delete won't fail
    $pdo->prepare('UPDATE products SET location_id=NULL WHERE location_id=?')->execute([$id]);
    $pdo->prepare('DELETE FROM locations WHERE id=?')->execute([$id]);
    log_action($pdo,current_user()['id'],'delete','locations',$id,'Location deleted',null,null);
  } catch (Throwable $e) {
    echo '<div class="alert alert-danger m-3">Delete failed: '.h($e->getMessage()).'</div>';
  }
}
header('Location: /profitradar/public/locations.php'); exit;
