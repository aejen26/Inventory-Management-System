<?php
require_once __DIR__.'/../includes/header.php';
require_role(['admin','staff']);
$pdo = getDB(); 
check_csrf();

$items = $_POST['items'] ?? [];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $supplier_id = ($_POST['supplier_id']!=='') ? (int)$_POST['supplier_id'] : null;
  $date  = $_POST['date'] ?: date('Y-m-d');
  $notes = trim($_POST['notes'] ?? '');

  // Prefetch product modes to normalize qty server-side
  $prodRows = $pdo->query("SELECT id, sold_by, unit FROM products")->fetchAll(PDO::FETCH_ASSOC);
  $prodIndex = [];
  foreach ($prodRows as $pr) { $prodIndex[(int)$pr['id']] = $pr; }

  $clean = [];
  foreach ($items as $i) {
    $pid   = (int)($i['product_id'] ?? 0);
    $qtyIn = (float)($i['qty'] ?? 0);
    $price = (float)($i['unit_price'] ?? 0);

    if ($pid > 0 && $qtyIn > 0) {
      $sold_by = $prodIndex[$pid]['sold_by'] ?? 'each';
      // Normalize qty based on sold_by
      $qty = ($sold_by === 'weight') ? round($qtyIn, 3) : (int)round($qtyIn);
      if ($qty > 0) {
        $clean[] = ['product_id'=>$pid, 'qty'=>$qty, 'unit_price'=>$price];
      }
    }
  }

  if ($clean) {
    create_transaction($pdo, 'purchase', current_user()['id'], $date, $notes, $supplier_id, null, $clean);
    $msg = '✅ Purchase recorded.';
  } else {
    $msg = 'Please add at least one item.';
  }
}

// include sold_by/unit **and stock_qty** so the UI can show clean stock text and set qty step
$products = $pdo->query("
  SELECT id, code, name, stock_qty, cost_price, sell_price, sold_by, unit
  FROM products 
  WHERE is_active=1 
  ORDER BY name
")->fetchAll(PDO::FETCH_ASSOC);

$sup = $pdo->query('SELECT id,name FROM suppliers ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0">Purchase (IN)</h4>
</div>

<?php if ($msg): ?>
  <div class="alert alert-info"><?= h($msg) ?></div>
<?php endif; ?>

<form method="post">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

  <div class="row g-2 mb-3">
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= h(date('Y-m-d')) ?>">
    </div>
    <div class="col-md-5">
      <label class="form-label">Supplier</label>
      <select class="form-select" name="supplier_id">
        <option value="">— none —</option>
        <?php foreach($sup as $s): ?>
          <option value="<?= (int)$s['id'] ?>"><?= h($s['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <table class="table table-sm align-middle" id="itemsTbl">
    <thead>
      <tr>
        <th style="width:45%">Product</th>
        <th style="width:15%">Qty</th>
        <th style="width:20%">Unit Price</th>
        <th style="width:10%">Line Total</th>
        <th style="width:10%"></th>
      </tr>
    </thead>
    <tbody></tbody>
    <tfoot>
      <tr>
        <th colspan="3" class="text-end">Grand Total:</th>
        <th id="grandTotal">₱0.00</th>
        <th></th>
      </tr>
    </tfoot>
  </table>

  <button type="button" class="btn btn-outline-secondary" onclick="addRow()">Add Item</button>

  <div class="mt-3 text-end">
    <textarea class="form-control mb-2" name="notes" placeholder="Notes (optional)"></textarea>
    <button class="btn btn-primary">Save Purchase</button>
  </div>
</form>

<script>
// Products payload with stock, cost & sell prices + sold_by/unit
const PRODUCTS = <?= json_encode($products, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;

function getProductById(id){
  id = parseInt(id, 10);
  return PRODUCTS.find(p => parseInt(p.id,10) === id);
}

function money(n){ 
  const v = Number(n||0);
  return '₱' + v.toFixed(2);
}

// NEW: pretty stock formatter (20.000 -> 20, 1.250 -> 1.25)
function fmtStockQty(qty){
  const n = parseFloat(qty);
  if (!isFinite(n)) return '0';
  return (n % 1 === 0) ? n.toFixed(0) : n.toFixed(3).replace(/\.?0+$/, '');
}

function recalcRow(tr){
  const qtyEl   = tr.querySelector('.qty');
  const priceEl = tr.querySelector('.unit-price');
  const totalEl = tr.querySelector('.line-total');

  const qty   = parseFloat(qtyEl.value || 0);
  const price = parseFloat(priceEl.value || 0);
  const line  = qty * price;

  totalEl.textContent = money(line);
  recalcGrand();
}

function recalcGrand(){
  let sum = 0;
  document.querySelectorAll('#itemsTbl tbody tr').forEach(tr=>{
    const qty   = parseFloat(tr.querySelector('.qty').value || 0);
    const price = parseFloat(tr.querySelector('.unit-price').value || 0);
    sum += qty * price;
  });
  document.getElementById('grandTotal').textContent = money(sum);
}

function onProductChange(e){
  const select = e.target;
  const tr     = select.closest('tr');
  const optVal = select.value;
  const prod   = getProductById(optVal);
  const priceEl= tr.querySelector('.unit-price');
  const qtyEl  = tr.querySelector('.qty');
  const hint   = tr.querySelector('.qty-hint');

  // PURCHASE page → use cost_price
  const cost = prod ? (parseFloat(prod.cost_price) || 0) : 0;
  priceEl.value = cost.toString();

  // Set qty input behavior based on sold_by
  if (prod && prod.sold_by === 'weight') {
    qtyEl.step = '0.001';
    qtyEl.min  = '0';
    qtyEl.placeholder = 'e.g., 1.250';
    hint.textContent = `Quantity in ${prod.unit || 'kg'} (decimals allowed)`;
    if (parseFloat(qtyEl.value||0) < 0.001) qtyEl.value = '0.001';
  } else {
    qtyEl.step = '1';
    qtyEl.min  = '1';
    qtyEl.placeholder = 'e.g., 1';
    hint.textContent = 'Quantity per piece (integer)';
    if (parseInt(qtyEl.value||0,10) < 1) qtyEl.value = '1';
  }

  recalcRow(tr);
}

function addRow(){
  const tb  = document.querySelector('#itemsTbl tbody');
  const idx = tb.children.length;

  // build options (now includes clean stock text)
  let opts = '<option value="">-- Select Product --</option>';
  for (const p of PRODUCTS) {
    const stock = (p.stock_qty == null) ? '' : ` (stock: ${fmtStockQty(p.stock_qty)} ${p.unit || 'pc'})`;
    const label = `${p.code} — ${p.name}${stock}`;
    opts += `<option value="${p.id}">${label.replace(/</g,'&lt;')}</option>`;
  }

  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td>
      <select class="form-select product-select" name="items[${idx}][product_id]" required>
        ${opts}
      </select>
    </td>
    <td>
      <input class="form-control qty" type="number" name="items[${idx}][qty]" value="1" min="1" step="1" placeholder="e.g., 1">
      <div class="form-text qty-hint">Quantity per piece (integer)</div>
    </td>
    <td>
      <input class="form-control unit-price" type="number" step="0.01" name="items[${idx}][unit_price]" value="0" readonly>
    </td>
    <td class="line-total">₱0.00</td>
    <td class="text-end">
      <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove(); recalcGrand();">Remove</button>
    </td>
  `;
  tb.appendChild(tr);

  // wire events
  const sel = tr.querySelector('.product-select');
  const qty = tr.querySelector('.qty');

  sel.addEventListener('change', onProductChange);
  qty.addEventListener('input', ()=>recalcRow(tr));
}

addRow(); // start with one row
</script>

<?php require_once __DIR__.'/../includes/footer.php'; ?>
