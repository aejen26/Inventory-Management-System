<?php
ob_start();
// /public/category_delete.php — delete category (admin only)
require_once __DIR__ . '/../includes/header.php';
require_role(['admin']);
$pdo = getDB();

$id = (int)($_GET['id'] ?? 0);
if ($id) {
  try {
    // Optional: unlink products first (set NULL, don't block delete)
    $pdo->prepare('UPDATE products SET category_id=NULL WHERE category_id=?')->execute([$id]);

    $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);
    log_action($pdo, current_user()['id'], 'delete', 'categories', $id, 'Category deleted', null, null);
  } catch (Throwable $e) {
    echo '<div class="alert alert-danger m-3">Delete failed: '.h($e->getMessage()).'</div>';
  }
}
header('Location: /profitradar/public/categories.php'); exit;
