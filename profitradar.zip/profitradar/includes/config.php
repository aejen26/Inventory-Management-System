<?php
const DB_DSN  = 'mysql:host=localhost;dbname=inventory;charset=utf8mb4';
const DB_USER = 'root';
const DB_PASS = '';

const APP_NAME = 'ProfitRadar Inventory';

// <-- ADD THIS: path from http://localhost to your project
const APP_BASE = '/profitradar';  // change if your folder name differs

// helper to build URLs consistently
function app_url(string $path): string {
    return rtrim(APP_BASE, '/') . '/public/' . ltrim($path, '/');
}
