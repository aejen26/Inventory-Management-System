<?php
// includes/header.php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
$pdo = getDB();
$lowCount = 0;
try {
  $lowCount = get_low_stock_count($pdo);
} catch (Throwable $e) {
  $lowCount = 0;
}

// ensure session for tickets
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// normalize tickets from session (support both indexed and assoc storage)
$ticketsRaw = $_SESSION['tickets'] ?? [];
$tickets = [];

/* Expected ticket structure (example):
   $_SESSION['tickets'] = [
     ['id'=>'a1b2','created_at'=>'2025-10-24 20:54','items'=>[...]],
     ...
   ];
   or associative keyed: 'a1b2' => ['id'=>'a1b2', ...]
*/
if ($ticketsRaw) {
  // If keyed by id => ticket
  $isAssoc = array_keys($ticketsRaw) !== range(0, count($ticketsRaw) - 1);
  if ($isAssoc) {
    foreach ($ticketsRaw as $k => $t) {
      if (is_array($t)) $tickets[] = $t;
    }
  } else {
    // indexed
    foreach ($ticketsRaw as $t) {
      if (is_array($t)) $tickets[] = $t;
    }
  }
  // sort by created_at if available (newest last) and then reverse to show newest first
  usort($tickets, function($a,$b){
    $ta = $a['created_at'] ?? null;
    $tb = $b['created_at'] ?? null;
    if ($ta && $tb) return strtotime($tb) <=> strtotime($ta);
    return 0;
  });
  // only keep most recent 10
  $tickets = array_slice($tickets, 0, 10);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
  <style>
    .badge-low { background:#dc3545; }
    .table-sm td,.table-sm th { padding:.35rem; }

    /* Tickets dropdown visuals */
    .tickets-list { max-height: 280px; overflow:auto; padding: 0.25rem 0.5rem; }
    .ticket-item { display:flex; align-items:center; justify-content:space-between; gap:0.5rem; padding:0.45rem 0.25rem; border-radius:4px; }
    .ticket-item:hover { background: rgba(0,0,0,0.03); }
    .ticket-meta { font-size:0.82rem; color: #4b5563; }
    .ticket-actions { display:flex; gap:0.35rem; align-items:center; }
    .ticket-id { font-weight:600; font-size:0.92rem; }
    .dropdown-header.tickets { font-size:0.8rem; color:#6c757d; padding:0.5rem 1rem; }
    /* small circle delete button style inside dropdown */
    .btn-ticket-del { padding: .15rem .4rem; line-height:1; font-size:0.8rem; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="/profitradar/public/dashboard.php"><?= h(APP_NAME) ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <!-- Products dropdown -->
        <!-- Products dropdown -->
<li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Products</a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="/profitradar/public/products.php">All Products</a></li>
    <li><a class="dropdown-item" href="/profitradar/public/categories.php">Categories</a></li>
    <li><a class="dropdown-item" href="/profitradar/public/suppliers.php">Suppliers</a></li>
    <!--<li><a class="dropdown-item" href="/profitradar/public/locations.php">Locations</a></li>-->
    <!--<li><a class="dropdown-item" href="<?= APP_BASE ?>/public/products_discounts.php">Discounts</a></li>
    <li><hr class="dropdown-divider"></li>-->
    <li><a class="dropdown-item" href="<?= APP_BASE ?>/public/tickets.php">Tickets</a></li>
  </ul>
</li>


        <!-- Transactions -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Transactions</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/profitradar/public/purchase_add.php">Purchase (IN)</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/sale_add.php">Sale (OUT)</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/stock_adjust.php">Stock Transfer</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/transactions.php">All Movements</a></li>            
          </ul>
        </li>

        <!-- Reports -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Reports</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/profitradar/public/reports/sales_report.php">Sales Report</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/reports/purchases_report.php">Purchases Report</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/reports/income_report.php">Income Report</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/reports/stock_movement.php">Stock Movement</a></li>
            <li><a class="dropdown-item" href="/profitradar/public/reports/forecast.php">7-Day Forecast</a></li>
          </ul>
        </li>

        <!-- Alerts -->
        <li class="nav-item">
          <a class="nav-link" href="/profitradar/public/low_stock.php">
            Alerts <span class="badge badge-low ms-1"><?= (int)$lowCount ?></span>
          </a>
        </li>

        <!-- Admin -->
        <?php if (has_role(['admin','auditor'])): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">User</a>
            <ul class="dropdown-menu">
              <!--<li><a class="dropdown-item" href="/profitradar/public/audit_log.php">Audit</a></li>-->
              <?php if (has_role('admin')): ?>
                <li><a class="dropdown-item" href="/profitradar/public/settings.php">Settings</a></li>
              <?php endif; ?>
            </ul>
          </li>
        <?php endif; ?>

      </ul>

      <div class="text-light">
        <?php if (is_logged_in()): ?>
          <!--<span class="me-2"> <?= h(current_user()['name']) ?> (<?= h(current_user()['role']) ?>)</span>-->
          <a class="btn btn-sm btn-outline-light" href="/profitradar/public/logout.php">Logout</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<div class="container py-3">
