<?php
ob_start();
// includes/auth.php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool {
    return !!current_user();
}

/**
 * True if the current user has the given role OR is admin.
 * Accepts a single role string or an array of roles.
 */
function has_role($role): bool {
    $u = current_user();
    if (!$u) return false;
    if ($u['role'] === 'admin') return true;

    if (is_array($role)) {
        return in_array($u['role'], $role, true);
    }
    return $u['role'] === $role;
}

function require_login() {
    if (!is_logged_in()) {
        // Use base-aware redirect if you added APP_BASE/app_url
        header('Location: /profitradar/public/login.php');
        exit;
    }
}

function require_role($roles) {
    require_login();
    if (!has_role($roles)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

function login(string $email, string $password): bool {
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        $_SESSION['user'] = [
            'id'    => (int)$u['id'],
            'name'  => $u['name'],
            'email' => $u['email'],
            'role'  => $u['role'],
        ];
        return true;
    }
    return false;
}

function logout() {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}
